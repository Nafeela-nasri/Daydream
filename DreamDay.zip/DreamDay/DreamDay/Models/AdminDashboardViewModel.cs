﻿namespace DreamDay.Models
{
    public class AdminDashboardViewModel
    {
        public int TotalCouples { get; set; }
        public int TotalPlanners { get; set; }
        public int TotalVendors { get; set; }

        // Properties to store chart data
        public List<BookingCountByDate> Last7DaysBookings { get; set; }
        public List<VendorCategoryCount> VendorCategoryDistribution { get; set; }
        public List<TopVenue> TopVenues { get; set; }
        public List<TopPlanner> TopPlanners { get; set; }
    }

    public class BookingCountByDate
    {
        public DateTime Date { get; set; }
        public int Count { get; set; }
    }

    public class VendorCategoryCount
    {
        public string Category { get; set; }
        public int Count { get; set; }
    }

    public class TopVenue
    {
        public string VenueName { get; set; }
        public int BookingCount { get; set; }
    }

    public class TopPlanner
    {
        public string PlannerName { get; set; }
        public int BookingCount { get; set; }
    }
}

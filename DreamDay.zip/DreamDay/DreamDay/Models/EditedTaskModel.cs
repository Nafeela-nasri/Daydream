﻿namespace DreamDay.Models
{
	public class EditedTaskModel
	{
		public int OriginalTaskId { get; set; }
		public string UpdatedTask { get; set; }
		public DateTime? UpdatedDueDate { get; set; }


		// Add this for planner support
		public int? CoupleId { get; set; }
	}
}

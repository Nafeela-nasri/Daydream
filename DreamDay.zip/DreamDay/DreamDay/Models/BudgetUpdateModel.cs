﻿namespace DreamDay.Models
{
    public class BudgetUpdateModel
    {
        public int UserId { get; set; }
        public decimal ActualAmount { get; set; }
        public int VenueId { get; set; }
        public int PlannerId { get; set; }
    }

}

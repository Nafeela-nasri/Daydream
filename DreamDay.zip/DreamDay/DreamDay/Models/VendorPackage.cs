﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DreamDay.Models
{
    public class VendorPackage
    {
        [Key]
        public int PackageId { get; set; }

        [Required]
        [ForeignKey("Vendor")]
        public int VendorId { get; set; }  // Explicitly saying VendorId is FK to Vendor

        [Required]
        public string PackageName { get; set; } = null!;

        [Required]
        public string Description { get; set; } = null!;

        [Required]
        [Column(TypeName = "decimal(18,2)")]
        public decimal Price { get; set; }

        public byte[]? Image { get; set; }

        public virtual Vendor Vendor { get; set; } = null!; // Navigation property

        public virtual ICollection<Booking> Bookings { get; set; } = new List<Booking>();

        //public virtual ICollection<Budget> Budgets { get; set; } = new List<Budget>();
    }
}

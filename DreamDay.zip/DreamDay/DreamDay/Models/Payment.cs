﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace DreamDay.Models
{
    public class Payment
    {
        [Key]
        public int PaymentID { get; set; }

        public DateTime Date { get; set; }

        [Required]
        public int UserID { get; set; }
        public int? PlannerID { get; set; }

        [Required]
        [Range(100, 100000000, ErrorMessage = "Amount should be reasonable.")]
        public decimal Amount { get; set; }
    }
}

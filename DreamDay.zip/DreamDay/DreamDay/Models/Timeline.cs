﻿using System.ComponentModel.DataAnnotations;

namespace DreamDay.Models
{
    public class Timeline
    {
        [Key]
        public int TimelineID { get; set; }
        public DateTime EventTime { get; set; }
        public string Tasks { get; set; }
        public string Duration { get; set; }
        public int UserID { get; set; }
    }
}

﻿namespace DreamDay.Models
{
	public class VendorPerformanceViewModel
	{
		public string VendorName { get; set; }
		public string Category { get; set; }
		public int BookingCount { get; set; }
	}

}

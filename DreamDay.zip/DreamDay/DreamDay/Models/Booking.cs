﻿using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DreamDay.Models
{
    public class Booking
    {
        public int BookingId { get; set; }

        [Required]
        public int UserID { get; set; }

        // keys for Vendor, Venue, and Planner
        public int? VenueId { get; set; }
        public int? PlannerId { get; set; }
        public int? PackageId { get; set; }

        public int? VendorId { get; set; } // FK to Vendor

		[Required]
        [DataType(DataType.Date)]
        [Display(Name = "Event Date")]
        public DateTime EventDate { get; set; } = DateTime.Now; //When the event is happening

        [Required]
        [Display(Name = "Event Time")]
        public string EventTime { get; set; } // "Lunch" or "Dinner"

        // Navigation properties
        [ForeignKey("PackageId")]
        [ValidateNever]
        public virtual VendorPackage VendorPackage { get; set; }
        [ValidateNever]
        public virtual Venue Venue { get; set; }
        [ValidateNever]
        public virtual Planner Planner { get; set; }
        [ValidateNever]
        public virtual User User { get; set; }
    }
}

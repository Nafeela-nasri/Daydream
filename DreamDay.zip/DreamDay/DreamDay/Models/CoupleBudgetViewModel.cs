﻿namespace DreamDay.Models
{
	public class CoupleBudgetViewModel
	{
		public string Name { get; set; }
		public decimal TotalBudget { get; set; }
	}

}

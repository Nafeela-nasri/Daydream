﻿namespace DreamDay.Models
{
    public class BudgetViewModel
    {
        public List<Budget> Budgets { get; set; } = new List<Budget>();
        public Budget NewBudget { get; set; } = new Budget();
    }
}

﻿using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DreamDay.Models
{
    public class Planner
    {
        [Key]
        public int PlannerId { get; set; }

        [Required]
        public string Name { get; set; } = null!;

        [ForeignKey("User")]
        public int UserID { get; set; }

        [Required]
        public string Description { get; set; } = null!;

        [Required]
        [Column(TypeName = "decimal(18,2)")]
        public decimal Price { get; set; }
        public string City { get; set; }
       
        [RegularExpression("^[0-9]*$", ErrorMessage = "Only numbers are allowed.")]
        public string? BusinessRegNo { get; set; }

        public byte[]? Image { get; set; }

        // Navigation property
        [ValidateNever]
        public virtual User User { get; set; } = null!;
        //public virtual ICollection<Booking> Bookings { get; set; } = new List<Booking>();
        public virtual ICollection<Review> Reviews { get; set; } = new List<Review>();
    }

	public class CoupleViewModel
	{
		public int UserID { get; set; }
		public string Fullname { get; set; }
		public string PhoneNumber { get; set; }
	}
}

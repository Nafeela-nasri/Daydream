﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DreamDay.Models
{
    public class Guest
    {
        [Key]
        public int GuestId { get; set; }

        [Required(ErrorMessage = "Guest name is required.")]
        [StringLength(100, ErrorMessage = "Guest name cannot exceed 100 characters.")]
        public string Name { get; set; } = null!;

        [EmailAddress(ErrorMessage = "Invalid email address.")]
        [StringLength(100, ErrorMessage = "Email cannot exceed 100 characters.")]
        public string? Email { get; set; }

        [StringLength(20, ErrorMessage = "Phone number cannot exceed 20 characters.")]
        public string? PhoneNo { get; set; }

        [Required(ErrorMessage = "Guest type is required.")]
        [StringLength(50, ErrorMessage = "Guest type cannot exceed 50 characters.")]
        public string GuestType { get; set; } = null!; // "Bride Side", "Groom Side", "Mutual"

        [Required(ErrorMessage = "Invitation status is required.")]
        [StringLength(20, ErrorMessage = "Invitation status cannot exceed 20 characters.")]
        public string InvitationStatus { get; set; } = "Not Sent"; // "Not Sent", "Sent", "Delivered"

        [Required(ErrorMessage = "RSVP status is required.")]
        [StringLength(20, ErrorMessage = "RSVP status cannot exceed 20 characters.")]
        public string RSVPStatus { get; set; } = "Pending"; // "Pending", "Accepted", "Declined"

        [StringLength(50, ErrorMessage = "Meal preference cannot exceed 50 characters.")]
        public string? MealPreference { get; set; } // "Vegetarian", "Non-Vegetarian", "Vegan", "Special"

        [StringLength(200, ErrorMessage = "Special requirements cannot exceed 200 characters.")]
        public string? SpecialRequirements { get; set; } // Dietary restrictions, accessibility needs, etc.

        [StringLength(50, ErrorMessage = "Table assignment cannot exceed 50 characters.")]
        public string? TableAssignment { get; set; } // Table number or name

        [Range(1, 10, ErrorMessage = "Number of accompanying guests must be between 1 and 10.")]
        public int AccompanyingGuests { get; set; } = 1; // Including themselves

        [StringLength(500, ErrorMessage = "Notes cannot exceed 500 characters.")]
        public string? Notes { get; set; } // Additional notes about the guest

        public DateTime CreatedDate { get; set; } = DateTime.Now;

        public DateTime? RSVPDate { get; set; } // Date when RSVP was received

        // Foreign key to User (Couple who created this guest entry)
        //[Required]
        public int UserId { get; set; }

        [ForeignKey("UserId")]
        public virtual User User { get; set; } = null!;
    }
}
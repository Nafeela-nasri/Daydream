﻿using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;

namespace DreamDay.Models
{
    public class Budget
    {

        public int BudgetId { get; set; }

        public int UserId { get; set; }

        public decimal? AllocatedAmount { get; set; }

       

        public string? CategoryName { get; set; }

        public decimal? ActualAmount { get; set; }
            
        [ValidateNever]
        public virtual User User { get; set; } = null!;

    }
}

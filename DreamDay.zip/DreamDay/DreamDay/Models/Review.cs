﻿using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using System.ComponentModel.DataAnnotations;

namespace DreamDay.Models
{
    public class Review
    {
        public int Id { get; set; }

        // Vendor Review
        public int? VendorId { get; set; } // <-- Nullable now

        // Venue Review
        public int? VenueId { get; set; } // <-- New

        public int? PlannerId { get; set; }

        [Required]
        public string Comment { get; set; }

        [ValidateNever]
        public Vendor Vendor { get; set; }

        [ValidateNever]
        public Venue Venue { get; set; } // <-- New

        [ValidateNever]
        public Planner Planner { get; set; }
    }
}

﻿namespace DreamDay.Models
{
	public class PopularVenueViewModel
	{
		public string VenueName { get; set; }
		public string Location { get; set; }
		public int BookingCount { get; set; }
	}

}

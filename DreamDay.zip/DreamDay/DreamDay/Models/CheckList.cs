﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace DreamDay.Models
{
	public class CheckList
	{
		[Key]
		public int CheckListId { get; set; }

		public int? UserId { get; set; }

		public string? Task { get; set; }

		public DateTime? DueDate { get; set; }   

		public string? Status { get; set; }

		[ForeignKey("UserId")]
		public virtual User? User { get; set; }
	}
}

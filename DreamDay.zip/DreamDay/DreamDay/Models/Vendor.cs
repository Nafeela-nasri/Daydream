﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DreamDay.Models
{
    public class Vendor
    {
        [Key]
        public int VendorId { get; set; }

        [Required]
        public string Category { get; set; } = null!;

        [Required]
        public string Name { get; set; } = null!;

        [Required]
        public string PhoneNo { get; set; } = null!;

        [Required]
        public string Address { get; set; } = null!;

        [Required]
        public string City { get; set; } = null!; 

        public byte[]? TitleImage { get; set; }

        public virtual ICollection<Review> Reviews { get; set; } = new List<Review>();

        public virtual ICollection<VendorPackage> VendorPackages { get; set; } = new List<VendorPackage>();

        public virtual ICollection<Booking> Bookings { get; set; } = new List<Booking>();

    }
}

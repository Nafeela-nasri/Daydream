﻿using Microsoft.EntityFrameworkCore;
using DreamDay.Models;

namespace DreamDay.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        // DbSets (tables) for your models
        public DbSet<User> Users { get; set; }
        public DbSet<Vendor> Vendors { get; set; }
        public DbSet<Venue> Venues { get; set; }
        public DbSet<VendorPackage> VendorPackages { get; set; }
        public DbSet<Planner> Planners { get; set; }
        public DbSet<Booking> Bookings { get; set; }
        public DbSet<Review> Reviews { get; set; }
        public DbSet<Budget> budgets { get; set; }
        public DbSet<Timeline> Timelines { get; set; }
        public DbSet<Payment> Payments { get; set; }
        public DbSet<CheckList> CheckList { get; set; }
        public DbSet<Guest> Guests { get; set; } // New Guest DbSet

    }

}
﻿// DreamDay Wedding Planner - Main JavaScript
document.addEventListener('DOMContentLoaded', function () {
    // Initialize tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl)
    });

    // Initialize popovers
    var popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'))
    var popoverList = popoverTriggerList.map(function (popoverTriggerEl) {
        return new bootstrap.Popover(popoverTriggerEl)
    });

    // Sidebar toggle functionality
    const sidebarToggle = document.getElementById('sidebar-toggle');
    const sidebarWrapper = document.getElementById('sidebar-wrapper');
    const pageContentWrapper = document.getElementById('page-content-wrapper');

    if (sidebarToggle) {
        sidebarToggle.addEventListener('click', function (e) {
            e.preventDefault();
            sidebarWrapper.classList.toggle('active');
            sidebarToggle.classList.toggle('active');
            pageContentWrapper.classList.toggle('active');
        });
    }

    // Close sidebar when clicking outside on mobile
    document.addEventListener('click', function (event) {
        const targetElement = event.target;

        if (window.innerWidth < 768 &&
            sidebarWrapper &&
            sidebarWrapper.classList.contains('active') &&
            !sidebarWrapper.contains(targetElement) &&
            targetElement !== sidebarToggle) {

            sidebarWrapper.classList.remove('active');
            if (sidebarToggle) {
                sidebarToggle.classList.remove('active');
            }
            if (pageContentWrapper) {
                pageContentWrapper.classList.remove('active');
            }
        }
    });

    // Toggle submenu in sidebar
    const sidebarItems = document.querySelectorAll('.sidebar-link-toggle');

    sidebarItems.forEach(function (item) {
        item.addEventListener('click', function (e) {
            e.preventDefault();
            const submenu = this.nextElementSibling;

            // Toggle aria-expanded attribute
            if (this.getAttribute('aria-expanded') === 'true') {
                this.setAttribute('aria-expanded', 'false');
            } else {
                this.setAttribute('aria-expanded', 'true');
            }

            // Toggle display of submenu
            if (submenu.style.display === 'block') {
                submenu.style.display = 'none';
            } else {
                submenu.style.display = 'block';
            }
        });
    });

    // Add active class to current nav item
    const currentLocation = window.location.pathname;
    const navLinks = document.querySelectorAll('.navbar-nav .nav-link, .sidebar-nav .sidebar-item');

    navLinks.forEach(function (link) {
        if (link.getAttribute('href') === currentLocation) {
            link.classList.add('active');

            // If in sidebar, expand parent if it's a submenu item
            if (link.closest('.sidebar-submenu')) {
                const parentToggle = link.closest('.sidebar-submenu').previousElementSibling;
                if (parentToggle && parentToggle.classList.contains('sidebar-link-toggle')) {
                    parentToggle.setAttribute('aria-expanded', 'true');
                    link.closest('.sidebar-submenu').style.display = 'block';
                }
            }
        }
    });

    // Form validation
    const forms = document.querySelectorAll('.needs-validation');

    Array.from(forms).forEach(function (form) {
        form.addEventListener('submit', function (event) {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }

            form.classList.add('was-validated');
        }, false);
    });

    // Auto-hide alerts after 5 seconds
    const alerts = document.querySelectorAll('.alert-auto-dismiss');

    alerts.forEach(function (alert) {
        setTimeout(function () {
            const bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        }, 5000);
    });

    // Initialize date pickers if any
    const datepickers = document.querySelectorAll('.datepicker');
    if (datepickers.length > 0 && typeof flatpickr !== 'undefined') {
        flatpickr('.datepicker', {
            dateFormat: "Y-m-d",
            altInput: true,
            altFormat: "F j, Y",
            allowInput: true
        });
    }

    // Toggle password visibility
    const togglePasswordButtons = document.querySelectorAll('.toggle-password');

    togglePasswordButtons.forEach(function (button) {
        button.addEventListener('click', function () {
            const passwordInput = document.querySelector(this.getAttribute('data-target'));

            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                this.innerHTML = '<i class="bi bi-eye-slash"></i>';
            } else {
                passwordInput.type = 'password';
                this.innerHTML = '<i class="bi bi-eye"></i>';
            }
        });
    });
});
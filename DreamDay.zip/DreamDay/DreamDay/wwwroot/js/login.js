﻿const backgrounds = [
    '/img/bglogin1.jpg',
    '/img/bglogin2.jpg',
    '/img/bglogin3.jpg'
];

let index = 0;
const backgroundDiv = document.querySelector('.background');

function rotateBackground() {
    backgroundDiv.style.backgroundImage = `url('${backgrounds[index]}')`;
    index = (index + 1) % backgrounds.length;
}

rotateBackground();
setInterval(rotateBackground, 2000); // Change image every 5 seconds

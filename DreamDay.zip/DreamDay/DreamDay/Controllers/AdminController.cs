﻿using DreamDay.Data;
using DreamDay.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace DreamDay.Controllers
{
    public class AdminController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly IWebHostEnvironment _webHostEnvironment;

        public AdminController(ApplicationDbContext context, IWebHostEnvironment webHostEnvironment)
        {
            _context = context;
            _webHostEnvironment = webHostEnvironment;
        }
        public IActionResult Dashboard()
        {
            // Optional: Check if session role is Admin
            if (HttpContext.Session.GetString("UserRole") != "Admin")
            {
                return RedirectToAction("Login", "Account");
            }
            // Get UserID from session
            var userId = HttpContext.Session.GetInt32("UserID");

            if (userId == null)
            {
                return RedirectToAction("Login", "Account");
            }

            // Pass the UserID to the view using ViewBag
            ViewBag.UserID = userId;

            //User Statistics
            var model = new AdminDashboardViewModel
            {
                TotalCouples = _context.Users.Count(u => u.UserRole == "Couple"),
                TotalPlanners = _context.Users.Count(u => u.UserRole == "Wedding Planner"),
                TotalVendors = _context.Vendors.Count()
            };

            // Get statistics for charts
            var last7DaysBookings = _context.Bookings
                .Where(b => b.EventDate >= DateTime.Now.AddDays(-7))
                .GroupBy(b => b.EventDate.Date)
                .OrderBy(g => g.Key)
                .Select(g => new BookingCountByDate
                {
                    Date = g.Key,
                    Count = g.Count()
                })
                .ToList();

            var vendorCategoryDistribution = _context.Vendors
                .GroupBy(v => v.Category)
                .Select(g => new VendorCategoryCount
                {
                    Category = g.Key,
                    Count = g.Count()
                })
                .ToList();

            var topVenues = (from booking in _context.Bookings
                             join venue in _context.Venues on booking.VenueId equals venue.VenueId
                             group booking by new { booking.VenueId, venue.Name } into g
                             orderby g.Count() descending
                             select new TopVenue
                             {
                                 VenueName = g.Key.Name,
                                 BookingCount = g.Count()
                             })
                  .Take(10)
                  .ToList();

            var topPlanners = (from booking in _context.Bookings
                               join user in _context.Users on booking.PlannerId equals user.UserID
                               group booking by new { booking.PlannerId, user.Fullname } into g
                               orderby g.Count() descending
                               select new TopPlanner
                               {
                                   PlannerName = g.Key.Fullname, // Use g.Key.Fullname here
                                   BookingCount = g.Count()
                               })
                        .Take(10)
                        .ToList();

            // Prepare the full model with all data
            model.Last7DaysBookings = last7DaysBookings;
            model.VendorCategoryDistribution = vendorCategoryDistribution;
            model.TopVenues = topVenues;
            model.TopPlanners = topPlanners;

            return View(model);
        }

        //User Management
        public IActionResult ManageUsers(string role)
        {
            ViewBag.Roles = new List<string> { "Admin", "Couple", "Wedding Planner" };  // Example roles
            ViewBag.SelectedRole = role;  // Pass the selected role to the view

            var users = _context.Users.ToList();  // Fetch users from the database

            if (!string.IsNullOrEmpty(role))
            {
                users = users.Where(u => u.UserRole == role).ToList();  // Filter users by role
            }

            return View(users);
        }

        [HttpPost]
        public IActionResult EditUser(User updatedUser)
        {
            if (updatedUser == null)
            {
                // Add error handling here, maybe return an error message or view
                return RedirectToAction("ManageUsers");
            }

            var user = _context.Users.Find(updatedUser.UserID);
            if (user != null)
            {
                user.Fullname = updatedUser.Fullname;
                user.Email = updatedUser.Email;
                user.PhoneNo = updatedUser.PhoneNo;
                user.Address = updatedUser.Address;
                user.NIC = updatedUser.NIC;
                user.UserRole = updatedUser.UserRole;
                _context.SaveChanges();
            }

            return RedirectToAction("ManageUsers");
        }

        public IActionResult DeleteUser(int id)
        {
            var user = _context.Users.Find(id);
            if (user != null)
            {
                _context.Users.Remove(user);
                _context.SaveChanges();
            }

            return RedirectToAction("ManageUsers");
        }


        // View all vendors
        // GET: Admin/VendorIndex
        public IActionResult VendorIndex(string? category)
        {
            var vendors = _context.Vendors.AsQueryable();

            if (!string.IsNullOrEmpty(category))
                vendors = vendors.Where(v => v.Category == category);

            ViewBag.Categories = _context.Vendors.Select(v => v.Category).Distinct().ToList();
            ViewBag.SelectedCategory = category;

            return View(vendors.ToList());
        }

        // GET: Admin/AddVendor
        public IActionResult AddVendor()
        {
            // Return a new Vendor instance to avoid null reference in the view
            return View(new Vendor());
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult AddVendor(Vendor vendor, IFormFile? imageFile)
        {
            if (imageFile != null && imageFile.Length > 0)
            {
                using var ms = new MemoryStream();
                imageFile.CopyTo(ms);
                vendor.TitleImage = ms.ToArray();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Vendors.Add(vendor);
                    _context.SaveChanges();
                    return RedirectToAction(nameof(VendorIndex));
                }
                catch (DbUpdateException ex)
                {
                    // Log or view the actual issue
                    ModelState.AddModelError(string.Empty, "Database error: " + ex.InnerException?.Message);
                }
            }

            return View(vendor);
        }
        // GET: Admin/EditVendor/5
        public IActionResult EditVendor(int id)
        {
            var vendor = _context.Vendors.Find(id);
            if (vendor == null) return NotFound();
            return View(vendor);
        }

        // POST: Admin/EditVendor
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult EditVendor(Vendor vendor, IFormFile? imageFile)
        {
            if (!ModelState.IsValid)
            {
                return View(vendor);
            }

            // Get the existing vendor from DB to preserve original image if needed
            var existingVendor = _context.Vendors.AsNoTracking().FirstOrDefault(v => v.VendorId == vendor.VendorId);
            if (existingVendor == null) return NotFound();

            if (imageFile != null)
            {
                using var ms = new MemoryStream();
                imageFile.CopyTo(ms);
                vendor.TitleImage = ms.ToArray();
            }
            else
            {
                vendor.TitleImage = existingVendor.TitleImage; // Preserve old image
            }

            _context.Vendors.Update(vendor);
            _context.SaveChanges(); // ✅ Save changes

            return RedirectToAction(nameof(VendorIndex));
        }


        // GET: Admin/DeleteVendor/5
        public IActionResult DeleteVendor(int id)
        {
            var vendor = _context.Vendors.Find(id);
            if (vendor == null) return NotFound();

            _context.Vendors.Remove(vendor);
            _context.SaveChanges();

            return RedirectToAction(nameof(VendorIndex));
        }


        //Reporting
        public IActionResult AdminReports() => View();

        public IActionResult GenerateReport(string type, DateTime start, DateTime end)
        {
            switch (type.ToLower())
            {
                case "payment":
                    var payments = _context.Payments
                        .Where(p => p.Date >= start && p.Date <= end)
                        .ToList();
                    var totalPayment = payments.Sum(p => p.Amount);
                    ViewBag.Total = totalPayment;
                    return PartialView("_PaymentReport", payments);

                case "booking":
                    var bookings = _context.Bookings
                        .Where(b => b.EventDate >= start && b.EventDate <= end)
                        .ToList();
                    ViewBag.Total = bookings.Count;
                    return PartialView("_BookingReport", bookings);

                case "planner":
                    var plannerStats = _context.Bookings
                        .GroupBy(b => b.PlannerId)
                        .Select(g => new
                        {
                            PlannerId = g.Key,
                            Count = g.Count()
                        })
                        .OrderByDescending(x => x.Count)
                        .ToList();
                    return PartialView("_PlannerReport", plannerStats);

                default:
                    return Content("Invalid report type");
            }
        }

    }
}


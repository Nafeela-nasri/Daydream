﻿using Microsoft.AspNetCore.Mvc;

namespace DreamDay.Controllers
{
    public class CoupleDashbaord : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}

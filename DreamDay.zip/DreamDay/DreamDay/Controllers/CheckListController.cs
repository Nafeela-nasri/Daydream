﻿using DreamDay.Data;
using Microsoft.AspNetCore.Mvc;
using DreamDay.Models;

namespace DreamDay.Controllers
{
	public class CheckListController : Controller
	{
		private readonly ApplicationDbContext _db;

		public CheckListController(ApplicationDbContext db)
		{
			_db = db;
		}
		public IActionResult CheckList()
		{
			int? userId = HttpContext.Session.GetInt32("UserID");
			if (!userId.HasValue)
			{
				TempData["Error"] = "User session expired.";
				return RedirectToAction("Login", "Account");
			}

			var checklistItems = _db.CheckList
				.Where(b => b.UserId == userId ||
						   (b.UserId == null && !_db.CheckList.Any(x => x.UserId == userId && x.Task == b.Task)))
				.OrderBy(b => b.DueDate) // 🟢 Sort by due date (earliest first)
				.ToList();
			return View(checklistItems);
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public IActionResult SaveEditedTask([FromBody] EditedTaskModel model)
		{
			int? userId = HttpContext.Session.GetInt32("UserID");
			if (!userId.HasValue)
			{
				return Json(new { success = false, message = "Session expired." });
			}

			var originalTask = _db.CheckList.FirstOrDefault(x => x.CheckListId == model.OriginalTaskId);

			if (originalTask == null)
			{
				return Json(new { success = false, message = "Original task not found." });
			}

			// 🟢 Case 1: Original task is a default task → INSERT new row
			if (originalTask.UserId == null)
			{
				var newTask = new CheckList
				{
					Task = model.UpdatedTask,
					DueDate = model.UpdatedDueDate,
					UserId = userId.Value,
					Status = "Pending"
				};

				_db.CheckList.Add(newTask);
				_db.SaveChanges();

				return Json(new { success = true, message = "Custom task saved." });
			}

			// 🟢 Case 2: Task already belongs to user → UPDATE that row
			if (originalTask.UserId == userId.Value)
			{
				originalTask.Task = model.UpdatedTask;
				originalTask.DueDate = model.UpdatedDueDate;

				_db.SaveChanges();

				return Json(new { success = true, message = "Task updated." });
			}

			return Json(new { success = false, message = "Unauthorized update attempt." });
		}


		[HttpPost]
		[ValidateAntiForgeryToken]
		public IActionResult ToggleStatus([FromBody] int checkListId)
		{
			int? userId = HttpContext.Session.GetInt32("UserID");
			if (!userId.HasValue)
			{
				return Json(new { success = false, message = "Session expired." });
			}

			var task = _db.CheckList.FirstOrDefault(x => x.CheckListId == checkListId && x.UserId == userId.Value);
			if (task == null)
			{
				return Json(new { success = false, message = "Task not found or not owned by user." });
			}

			task.Status = task.Status == "Completed" ? "Incomplete" : "Completed";
			_db.SaveChanges();

			return Json(new { success = true, newStatus = task.Status });
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public IActionResult DeleteTask([FromBody] int checkListId)
		{
			int? userId = HttpContext.Session.GetInt32("UserID");
			if (!userId.HasValue)
			{
				return Json(new { success = false, message = "Session expired." });
			}

			var task = _db.CheckList.FirstOrDefault(x => x.CheckListId == checkListId && x.UserId == userId.Value);

			if (task == null)
			{
				return Json(new { success = false, message = "Task not found or not owned by user." });
			}

			_db.CheckList.Remove(task);
			_db.SaveChanges();

			return Json(new { success = true, message = "Task deleted successfully." });
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public IActionResult AddTask([FromBody] NewTaskModel model)
		{
			int? userId = HttpContext.Session.GetInt32("UserID");
			if (!userId.HasValue)
			{
				return Json(new { success = false, message = "Session expired." });
			}

			if (string.IsNullOrWhiteSpace(model.Task))
			{
				return Json(new { success = false, message = "Task title cannot be empty." });
			}

			var task = new CheckList
			{
				Task = model.Task,
				DueDate = model.DueDate,
				Status = "Incomplete",
				UserId = userId.Value
			};

			_db.CheckList.Add(task);
			_db.SaveChanges();

			return Json(new
			{
				success = true,
				newId = task.CheckListId,
				task = task.Task,
				dueDate = task.DueDate?.ToString("dd MMM yyyy"),
				status = task.Status
			});
		}

		public class NewTaskModel
		{
			public string Task { get; set; }
			public DateTime? DueDate { get; set; }
		}


	}
}

﻿using DreamDay.Data;
using DreamDay.Helpers;
using DreamDay.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace DreamDay.Controllers
{
    public class BudgetController : Controller
    {
        private readonly ApplicationDbContext _db;

        public BudgetController(ApplicationDbContext db)
        {
            _db = db;
        }
		public IActionResult Budget()
		{
			int? userId = HttpContext.Session.GetInt32("UserID");
			if (!userId.HasValue)
			{
				TempData["Error"] = "User session expired.";
				return RedirectToAction("Login", "Account");
			}

			var budgets = _db.budgets.Where(b => b.UserId == userId).ToList();

			// Calculations
			decimal totalAllocated = budgets.Sum(b => b.AllocatedAmount ?? 0);
			decimal totalUsed = budgets.Sum(b => b.ActualAmount ?? 0);
			decimal remaining = totalAllocated - totalUsed;

			// Pass to view via ViewBag
			ViewBag.TotalBudget = totalAllocated;
			ViewBag.TotalUsed = totalUsed;
			ViewBag.RemainingBudget = remaining;

			var viewModel = new BudgetViewModel
			{
				Budgets = budgets
			};

			return View(viewModel);
		}

		public IActionResult AddBudget()
		{
			var budget = new Budget(); // Empty Budget object
			return PartialView("_AddBudgetModal", budget);
		}

		[HttpPost]
		public async Task<IActionResult> AddBudget(BudgetViewModel viewModel)
		{
			var userSession = HttpContext.Session.GetObject<UserSession>("UserSession");

			if (userSession != null)
			{
				viewModel.NewBudget.UserId = userSession.UserId;
			}

			if (!ModelState.IsValid)
			{
				var errors = ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage).ToList();
				TempData["ErrorMessage"] = "Validation failed: " + string.Join(", ", errors);
				return RedirectToAction("Budget");
			}

			try
			{
				// No VenueId or PlannerId, just add the budget
				_db.budgets.Add(viewModel.NewBudget);
				await _db.SaveChangesAsync();
				TempData["SuccessMessage"] = "Budget added successfully!";
			}
			catch (Exception ex)
			{
				TempData["ErrorMessage"] = "Database error: " + ex.Message;
			}

			return RedirectToAction("Budget");
		}

		[HttpPost]
		[ValidateAntiForgeryToken]
		public IActionResult EditBudget(Budget updatedBudget)
		{
			if (!ModelState.IsValid)
			{
				TempData["Error"] = "Invalid data submitted.";
				return RedirectToAction("Budget");
			}

			var userId = HttpContext.Session.GetInt32("UserID");
			if (!userId.HasValue)
			{
				TempData["Error"] = "User not authenticated.";
				return RedirectToAction("Login", "Account");
			}

			// Fetch the existing budget from the database
			var existingBudget = _db.budgets.FirstOrDefault(b => b.BudgetId == updatedBudget.BudgetId && b.UserId == userId.Value);

			if (existingBudget == null)
			{
				TempData["Error"] = "Budget not found.";
				return RedirectToAction("Budget");
			}

			// Update the fields
			existingBudget.CategoryName = updatedBudget.CategoryName;
			existingBudget.AllocatedAmount = updatedBudget.AllocatedAmount;

			// Save changes
			_db.SaveChanges();

			TempData["Success"] = "Budget updated successfully!";
			return RedirectToAction("Budget");
		}

		[HttpPost]
		public IActionResult DeleteBudget(int id)
		{
			var budget = _db.budgets.FirstOrDefault(b => b.BudgetId == id);
			if (budget != null)
			{
				_db.budgets.Remove(budget);
				_db.SaveChanges();
				TempData["Success"] = "Budget deleted successfully!";
			}
			else
			{
				TempData["Error"] = "Budget not found.";
			}

			return RedirectToAction("Budget");
		}

		public IActionResult BudgetList()
		{
			var userId = HttpContext.Session.GetInt32("UserID");
			var budgets = _db.budgets.Where(b => b.UserId == userId).ToList();
			return View(budgets);
		}

		// Action to get user budget details
		[HttpGet]
		public IActionResult GetUserBudget(int userId)
		{
			var budgets = _db.budgets
				.Where(b => b.UserId == userId)
				.ToList();

			// Return the budgets including category names
			return Json(budgets.Select(b => new
			{
				b.BudgetId,
				b.UserId,
				b.CategoryName,
				b.AllocatedAmount
			}));
		}

		[HttpPost]
		public IActionResult UpdateActualAmount([FromBody] BudgetUpdateModel model)
		{
			if (model == null || model.UserId <= 0 || model.ActualAmount <= 0)
			{
				return Json(new { success = false, message = "Invalid data." });
			}

			// Filter by user and "Planner" category
			var budget = _db.budgets.FirstOrDefault(b => b.UserId == model.UserId && b.CategoryName == "Planner");
			if (budget == null)
			{
				return Json(new { success = false, message = "Planner budget not found." });
			}

			if (model.ActualAmount > budget.AllocatedAmount)
			{
				return Json(new { success = false, message = "Actual amount cannot exceed allocated amount." });
			}

			budget.ActualAmount = model.ActualAmount;
			_db.SaveChanges();

			return Json(new { success = true, message = "Budget updated successfully." });
		}


		public IActionResult GetUserBudgetByCategory(string categoryName)
		{
			var userSession = HttpContext.Session.GetObject<UserSession>("UserSession");

			if (userSession == null)
			{
				return Json(new { success = false, message = "User not logged in" });
			}

			var budget = _db.budgets
				.FirstOrDefault(b => b.UserId == userSession.UserId && b.CategoryName == categoryName);

			if (budget == null)
			{
				return Json(new { success = false, message = "No budget found for this category." });
			}

			return Json(new
			{
				success = true,
				allocatedAmount = budget.AllocatedAmount ?? 0
			});
		}
		[HttpGet]
		public IActionResult GetUserBudgetForVendorCategory(int userId, string vendorCategory)
		{
			var budget = _db.budgets
				.FirstOrDefault(b => b.UserId == userId && b.CategoryName == vendorCategory);

			if (budget == null)
			{
				return Json(new { success = false, message = "No budget allocated for this category." });
			}

			return Json(new { success = true, allocatedAmount = budget.AllocatedAmount });
		}

		//public IActionResult Budget()
		//{
		//    int? userId = HttpContext.Session.GetInt32("UserID");
		//    if (!userId.HasValue)
		//    {
		//        TempData["Error"] = "User session expired.";
		//        return RedirectToAction("Login", "Account");
		//    }

		//    var budgets = _db.budgets.Where(b => b.UserId == userId).ToList();

		//    // Calculations
		//    decimal totalAllocated = budgets.Sum(b => b.AllocatedAmount ?? 0);
		//    decimal totalUsed = budgets.Sum(b => b.ActualAmount ?? 0);
		//    decimal remaining = totalAllocated - totalUsed;

		//    // Pass to view via ViewBag
		//    ViewBag.TotalBudget = totalAllocated;
		//    ViewBag.TotalUsed = totalUsed;
		//    ViewBag.RemainingBudget = remaining;

		//    var viewModel = new BudgetViewModel
		//    {
		//        Budgets = budgets
		//    };

		//    return View(viewModel);
		//}

		//public IActionResult AddBudget()
		//{
		//    var budget = new Budget(); // Empty Budget object
		//    return PartialView("_AddBudgetModal", budget);
		//}

		//[HttpPost]
		//public async Task<IActionResult> AddBudget(BudgetViewModel viewModel)
		//{
		//    var userSession = HttpContext.Session.GetObject<UserSession>("UserSession");

		//    if (userSession != null)
		//    {
		//        viewModel.NewBudget.UserId = userSession.UserId;
		//    }

		//    if (!ModelState.IsValid)
		//    {
		//        var errors = ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage).ToList();
		//        TempData["ErrorMessage"] = "Validation failed: " + string.Join(", ", errors);
		//        return RedirectToAction("Budget");
		//    }

		//    try
		//    {
		//        // No VenueId or PlannerId, just add the budget
		//        _db.budgets.Add(viewModel.NewBudget);
		//        await _db.SaveChangesAsync();
		//        TempData["SuccessMessage"] = "Budget added successfully!";
		//    }
		//    catch (Exception ex)
		//    {
		//        TempData["ErrorMessage"] = "Database error: " + ex.Message;
		//    }

		//    return RedirectToAction("Budget");
		//}

		//[HttpPost]
		//[ValidateAntiForgeryToken]
		//public IActionResult EditBudget(Budget updatedBudget)
		//{
		//    if (!ModelState.IsValid)
		//    {
		//        TempData["Error"] = "Invalid data submitted.";
		//        return RedirectToAction("Budget");
		//    }

		//    var userId = HttpContext.Session.GetInt32("UserID");
		//    if (!userId.HasValue)
		//    {
		//        TempData["Error"] = "User not authenticated.";
		//        return RedirectToAction("Login", "Account");
		//    }

		//    // Fetch the existing budget from the database
		//    var existingBudget = _db.budgets.FirstOrDefault(b => b.BudgetId == updatedBudget.BudgetId && b.UserId == userId.Value);

		//    if (existingBudget == null)
		//    {
		//        TempData["Error"] = "Budget not found.";
		//        return RedirectToAction("Budget");
		//    }

		//    // Update the fields
		//    existingBudget.CategoryName = updatedBudget.CategoryName;
		//    existingBudget.AllocatedAmount = updatedBudget.AllocatedAmount;

		//    // Save changes
		//    _db.SaveChanges();

		//    TempData["Success"] = "Budget updated successfully!";
		//    return RedirectToAction("Budget");
		//}

		//[HttpPost]
		//public IActionResult DeleteBudget(int id)
		//{
		//    var budget = _db.budgets.FirstOrDefault(b => b.BudgetId == id);
		//    if (budget != null)
		//    {
		//        _db.budgets.Remove(budget);
		//        _db.SaveChanges();
		//        TempData["Success"] = "Budget deleted successfully!";
		//    }
		//    else
		//    {
		//        TempData["Error"] = "Budget not found.";
		//    }

		//    return RedirectToAction("Budget");
		//}

		//public IActionResult BudgetList()
		//{
		//    var userId = HttpContext.Session.GetInt32("UserID");
		//    var budgets = _db.budgets.Where(b => b.UserId == userId).ToList();
		//    return View(budgets);
		//}

		//// Action to get user budget details
		//[HttpGet]
		//public IActionResult GetUserBudget(int userId)
		//{
		//    var budgets = _db.budgets
		//        .Where(b => b.UserId == userId)
		//        .ToList();

		//    // Return the budgets including category names
		//    return Json(budgets.Select(b => new
		//    {
		//        b.BudgetId,
		//        b.UserId,
		//        b.CategoryName,
		//        b.AllocatedAmount
		//    }));
		//}

		//[HttpPost]
		//public IActionResult UpdateActualAmount([FromBody] BudgetUpdateModel model)
		//{
		//    if (model == null || model.UserId <= 0 || model.ActualAmount <= 0)
		//    {
		//        return Json(new { success = false, message = "Invalid data." });
		//    }

		//    // Filter by user and "Planner" category
		//    var budget = _db.budgets.FirstOrDefault(b => b.UserId == model.UserId && b.CategoryName == "Planner");
		//    if (budget == null)
		//    {
		//        return Json(new { success = false, message = "Planner budget not found." });
		//    }

		//    if (model.ActualAmount > budget.AllocatedAmount)
		//    {
		//        return Json(new { success = false, message = "Actual amount cannot exceed allocated amount." });
		//    }

		//    budget.ActualAmount = model.ActualAmount;
		//    _db.SaveChanges();

		//    return Json(new { success = true, message = "Budget updated successfully." });
		//}


		//public IActionResult GetUserBudgetByCategory(string categoryName)
		//{
		//    var userSession = HttpContext.Session.GetObject<UserSession>("UserSession");

		//    if (userSession == null)
		//    {
		//        return Json(new { success = false, message = "User not logged in" });
		//    }

		//    var budget = _db.budgets
		//        .FirstOrDefault(b => b.UserId == userSession.UserId && b.CategoryName == categoryName);

		//    if (budget == null)
		//    {
		//        return Json(new { success = false, message = "No budget found for this category." });
		//    }

		//    return Json(new
		//    {
		//        success = true,
		//        allocatedAmount = budget.AllocatedAmount ?? 0
		//    });
		//}
		//[HttpGet]
		//public IActionResult GetUserBudgetForVendorCategory(int userId, string vendorCategory)
		//{
		//    var budget = _db.budgets
		//        .FirstOrDefault(b => b.UserId == userId && b.CategoryName == vendorCategory);

		//    if (budget == null)
		//    {
		//        return Json(new { success = false, message = "No budget allocated for this category." });
		//    }

		//    return Json(new { success = true, allocatedAmount = budget.AllocatedAmount });
		//}


	}
}


﻿using Microsoft.AspNetCore.Mvc;
using DreamDay.Data;
using DreamDay.Models;
using Microsoft.AspNetCore.Http;
using DreamDay.Helpers;
using System;
using System.Linq;
using Microsoft.EntityFrameworkCore;

namespace DreamDay.Controllers
{
    public class BookingController : Controller
    {
        private readonly ApplicationDbContext _context;

        public BookingController(ApplicationDbContext context)
        {
            _context = context;
        }

		// GET: Booking/Create
		[HttpGet]
		public IActionResult Create(int? venueId, int? plannerId, int? packageId)
		{
			var userSession = HttpContext.Session.GetObject<UserSession>("UserSession");
			if (userSession == null)
			{
				return RedirectToAction("Login", "Account");
			}

			var booking = new Booking
			{
				UserID = userSession.UserId,
				VenueId = venueId,
				PlannerId = plannerId,
				PackageId = packageId
			};

			// Load selected venue details
			if (venueId.HasValue)
			{
				var venue = _context.Venues.FirstOrDefault(v => v.VenueId == venueId);
				if (venue != null)
				{
					ViewBag.VenueName = venue.Name;
					ViewBag.VenuePrice = venue.Price;
				}
			}

			// Load selected planner details
			if (plannerId.HasValue)
			{
				var planner = _context.Vendors.FirstOrDefault(p => p.VendorId == plannerId);
				if (planner != null)
				{
					ViewBag.PlannerName = planner.Name;
					ViewBag.PlannerCategory = planner.Category;
				}
			}

			// Load selected package details
			if (packageId.HasValue)
			{
				var package = _context.VendorPackages
					.Include(p => p.Vendor)
					.FirstOrDefault(p => p.PackageId == packageId.Value);

				if (package != null)
				{
					ViewBag.PackageName = package.PackageName;
					ViewBag.PackagePrice = package.Price;
					ViewBag.PackageCategory = package.Vendor.Category;
					ViewBag.VendorName = package.Vendor.Name;
				}
			}

			return View(booking);
		}

		// POST: Booking/Create
		[HttpPost]
		public IActionResult Create(Booking booking)
		{
			if (!ModelState.IsValid)
			{
				TempData["ErrorMessage"] = "Please correct the errors in the form.";
				return View(booking);
			}

			// Booking conflict checks
			if (booking.VenueId.HasValue)
			{
				var venueConflict = _context.Bookings.FirstOrDefault(b =>
					b.VenueId == booking.VenueId &&
					b.EventDate == booking.EventDate &&
					b.EventTime == booking.EventTime);

				if (venueConflict != null)
				{
					TempData["ErrorMessage"] = "The selected venue is already booked at this date and time.";
					return View(booking);
				}
			}

			if (booking.PlannerId.HasValue)
			{
				var plannerConflict = _context.Bookings.FirstOrDefault(b =>
					b.PlannerId == booking.PlannerId &&
					b.EventDate == booking.EventDate &&
					b.EventTime == booking.EventTime);

				if (plannerConflict != null)
				{
					TempData["ErrorMessage"] = "The selected planner is already booked at this date and time.";
					return View(booking);
				}
			}

			if (booking.PackageId.HasValue)
			{
				var packageConflict = _context.Bookings.FirstOrDefault(b =>
					b.PackageId == booking.PackageId &&
					b.EventDate == booking.EventDate &&
					b.EventTime == booking.EventTime);

				if (packageConflict != null)
				{
					TempData["ErrorMessage"] = "The selected package is already booked at this date and time.";
					return View(booking);
				}
			}

			// Validate and process venue budget
			if (booking.VenueId.HasValue)
			{
				var venue = _context.Venues.FirstOrDefault(v => v.VenueId == booking.VenueId.Value);
				if (venue == null)
				{
					ModelState.AddModelError("", "The selected venue does not exist.");
					return View(booking);
				}

				var venueBudget = _context.budgets
					.FirstOrDefault(b => b.UserId == booking.UserID && b.CategoryName == "Venue");

				if (venueBudget != null)
				{
					venueBudget.ActualAmount = venue.Price;
					_context.Update(venueBudget);
				}
				else
				{
					ModelState.AddModelError("", "No venue budget found for this user.");
					return View(booking);
				}
			}

			// Handle vendor package budgets (Florist, Photography, Catering, etc.)
			if (booking.PackageId.HasValue)
			{
				var package = _context.VendorPackages
					.Include(p => p.Vendor)
					.FirstOrDefault(p => p.PackageId == booking.PackageId.Value);

				if (package != null)
				{
					var category = package.Vendor.Category;
					var budget = _context.budgets
						.FirstOrDefault(b => b.UserId == booking.UserID && b.CategoryName == category);

					if (budget != null)
					{
						budget.ActualAmount = package.Price;
						_context.Update(budget);
					}
					else
					{
						ModelState.AddModelError("", $"No budget found for category: {category}");
						return View(booking);
					}
				}
				else
				{
					ModelState.AddModelError("", "The selected package does not exist.");
					return View(booking);
				}
			}

			_context.Bookings.Add(booking);
			_context.SaveChanges();

			TempData["SuccessMessage"] = "Your booking has been successfully created!";
			return RedirectToAction("SelectPlanner", "Planner");
		}

		public IActionResult MyBookings()
		{
			var userId = HttpContext.Session.GetInt32("UserID");
			if (userId == null)
			{
				return RedirectToAction("Login", "User");
			}

			var bookings = _context.Bookings
				.Include(b => b.VendorPackage)
				.Include(b => b.Venue)
				.Include(b => b.Planner)
				.Where(b => b.UserID == userId)
				.ToList();

			return View(bookings);
		}


		//// GET: Booking/Create
		//[HttpGet]
		//public IActionResult Create(int? venueId, int? plannerId, int? packageId)
		//{
		//    var userSession = HttpContext.Session.GetObject<UserSession>("UserSession");
		//    if (userSession == null)
		//    {
		//        return RedirectToAction("Login", "Account");
		//    }

		//    var booking = new Booking
		//    {
		//        UserID = userSession.UserId,
		//        VenueId = venueId,
		//        PlannerId = plannerId,
		//        PackageId = packageId
		//    };

		//    // Load selected venue details
		//    if (venueId.HasValue)
		//    {
		//        var venue = _context.Venues.FirstOrDefault(v => v.VenueId == venueId);
		//        if (venue != null)
		//        {
		//            ViewBag.VenueName = venue.Name;
		//            ViewBag.VenuePrice = venue.Price;
		//        }
		//    }

		//    // Load selected planner details
		//    if (plannerId.HasValue)
		//    {
		//        var planner = _context.Vendors.FirstOrDefault(p => p.VendorId == plannerId);
		//        if (planner != null)
		//        {
		//            ViewBag.PlannerName = planner.Name;
		//            ViewBag.PlannerCategory = planner.Category;
		//        }
		//    }

		//    // Load selected package details
		//    if (packageId.HasValue)
		//    {
		//        var package = _context.VendorPackages
		//            .Include(p => p.Vendor)
		//            .FirstOrDefault(p => p.PackageId == packageId.Value);

		//        if (package != null)
		//        {
		//            ViewBag.PackageName = package.PackageName;
		//            ViewBag.PackagePrice = package.Price;
		//            ViewBag.PackageCategory = package.Vendor.Category;
		//            ViewBag.VendorName = package.Vendor.Name;
		//        }
		//    }

		//    return View(booking);
		//}

		//// POST: Booking/Create
		//[HttpPost]
		//public IActionResult Create(Booking booking)
		//{
		//    if (!ModelState.IsValid)
		//    {
		//        TempData["ErrorMessage"] = "Please correct the errors in the form.";
		//        return View(booking);
		//    }

		//    // Booking conflict checks
		//    if (booking.VenueId.HasValue)
		//    {
		//        var venueConflict = _context.Bookings.FirstOrDefault(b =>
		//            b.VenueId == booking.VenueId &&
		//            b.EventDate == booking.EventDate &&
		//            b.EventTime == booking.EventTime);

		//        if (venueConflict != null)
		//        {
		//            TempData["ErrorMessage"] = "The selected venue is already booked at this date and time.";
		//            return View(booking);
		//        }
		//    }

		//    if (booking.PlannerId.HasValue)
		//    {
		//        var plannerConflict = _context.Bookings.FirstOrDefault(b =>
		//            b.PlannerId == booking.PlannerId &&
		//            b.EventDate == booking.EventDate &&
		//            b.EventTime == booking.EventTime);

		//        if (plannerConflict != null)
		//        {
		//            TempData["ErrorMessage"] = "The selected planner is already booked at this date and time.";
		//            return View(booking);
		//        }
		//    }

		//    if (booking.PackageId.HasValue)
		//    {
		//        var packageConflict = _context.Bookings.FirstOrDefault(b =>
		//            b.PackageId == booking.PackageId &&
		//            b.EventDate == booking.EventDate &&
		//            b.EventTime == booking.EventTime);

		//        if (packageConflict != null)
		//        {
		//            TempData["ErrorMessage"] = "The selected package is already booked at this date and time.";
		//            return View(booking);
		//        }
		//    }

		//    // Validate and process venue budget
		//    if (booking.VenueId.HasValue)
		//    {
		//        var venue = _context.Venues.FirstOrDefault(v => v.VenueId == booking.VenueId.Value);
		//        if (venue == null)
		//        {
		//            ModelState.AddModelError("", "The selected venue does not exist.");
		//            return View(booking);
		//        }

		//        var venueBudget = _context.budgets
		//            .FirstOrDefault(b => b.UserId == booking.UserID && b.CategoryName == "Venue");

		//        if (venueBudget != null)
		//        {
		//            venueBudget.ActualAmount = venue.Price;
		//            _context.Update(venueBudget);
		//        }
		//        else
		//        {
		//            ModelState.AddModelError("", "No venue budget found for this user.");
		//            return View(booking);
		//        }
		//    }

		//    // Handle vendor package budgets (Florist, Photography, Catering, etc.)
		//    if (booking.PackageId.HasValue)
		//    {
		//        var package = _context.VendorPackages
		//            .Include(p => p.Vendor)
		//            .FirstOrDefault(p => p.PackageId == booking.PackageId.Value);

		//        if (package != null)
		//        {
		//            var category = package.Vendor.Category;
		//            var budget = _context.budgets
		//                .FirstOrDefault(b => b.UserId == booking.UserID && b.CategoryName == category);

		//            if (budget != null)
		//            {
		//                budget.ActualAmount = package.Price;
		//                _context.Update(budget);
		//            }
		//            else
		//            {
		//                ModelState.AddModelError("", $"No budget found for category: {category}");
		//                return View(booking);
		//            }
		//        }
		//        else
		//        {
		//            ModelState.AddModelError("", "The selected package does not exist.");
		//            return View(booking);
		//        }
		//    }

		//    _context.Bookings.Add(booking);
		//    _context.SaveChanges();

		//    TempData["SuccessMessage"] = "Your booking has been successfully created!";
		//    return RedirectToAction("SelectPlanner", "Planner");
		//}

		//public IActionResult MyBookings()
		//{
		//    var userId = HttpContext.Session.GetInt32("UserID");
		//    if (userId == null)
		//    {
		//        return RedirectToAction("Login", "User");
		//    }

		//    var bookings = _context.Bookings
		//        .Include(b => b.VendorPackage)
		//        .Include(b => b.Venue)
		//        .Include(b => b.Planner)
		//        .Where(b => b.UserID == userId)
		//        .ToList();

		//    return View(bookings);
		//}
	}
}

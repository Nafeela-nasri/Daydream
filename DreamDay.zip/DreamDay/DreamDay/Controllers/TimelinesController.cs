﻿using DreamDay.Data;
using DreamDay.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Globalization;

namespace DreamDay.Controllers
{
    public class TimelinesController : Controller
    {
        private readonly ApplicationDbContext _context;

        // Inject ApplicationDbContext through constructor
        public TimelinesController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Timelines
        public IActionResult Index()
        {
            // Get UserID from session
            var userId = HttpContext.Session.GetInt32("UserID");

            // Pass the UserID to the view using ViewBag
            ViewBag.UserID = userId;

            var timelines = _context.Timelines.ToList(); // Fetch all timelines from DB
            return View(timelines);
        }

        // GET: Timelines/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Timelines/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Timeline timeline)
        {
            if (ModelState.IsValid)
            {
                _context.Timelines.Add(timeline); // Add new timeline to DB
                _context.SaveChanges();
                return RedirectToAction(nameof(Index)); // Redirect to Index
            }
            return View(timeline);
        }

        // POST: Timelines/Edit
        [HttpPost]
        public IActionResult Edit(Timeline timeline)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    _context.Entry(timeline).State = EntityState.Modified;
                    _context.SaveChanges();
                    return Json(new { success = true });
                }
                catch (DbUpdateConcurrencyException)
                {
                    return Json(new { success = false, message = "Update failed. Try again." });
                }
            }
            return Json(new { success = false, message = "Invalid input data." });
        }

        // POST: Timelines/Delete/5
        [HttpPost]
        public IActionResult Delete(int id)
        {
            var timeline = _context.Timelines.Find(id);
            if (timeline != null)
            {
                _context.Timelines.Remove(timeline);
                _context.SaveChanges();
            }
            return Json(new { success = true });
        }

        [HttpPost]
        public JsonResult SaveEvents([FromBody] List<Timeline> events)
        {
            if (events == null || events.Count == 0)
            {
                return Json(new { success = false, message = "No events received." });
            }

            foreach (var e in events)
            {
                _context.Timelines.Add(e);
            }

            _context.SaveChanges(); // <-- This line was missing

            return Json(new { success = true });
        }

    }
}

﻿using System.Security.Claims;
using DreamDay.Data;
using DreamDay.Helpers;
using DreamDay.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace DreamDay.Controllers
{
	public class PlannerReportsController : Controller
	{
		//public IActionResult Index()
		//{
		//	return View();
		//}
		private readonly ApplicationDbContext _context;

		public PlannerReportsController(ApplicationDbContext context)
		{
			_context = context;
		}
		public IActionResult PopularVenues(DateTime? startDate, DateTime? endDate)
		{
			var bookings = _context.Bookings
				.Where(b => b.VenueId != null);

			if (startDate.HasValue && endDate.HasValue)
			{
				bookings = bookings.Where(b => b.EventDate >= startDate && b.EventDate <= endDate);
			}

			var venueStats = bookings
				.GroupBy(b => b.VenueId)
				.Select(g => new
				{
					VenueId = g.Key.Value,
					BookingCount = g.Count()
				})
				.OrderByDescending(g => g.BookingCount)
				.ToList();

			var venueDetails = venueStats
				.Join(_context.Venues,
					  stat => stat.VenueId,
					  venue => venue.VenueId,
					  (stat, venue) => new PopularVenueViewModel
					  {
						  VenueName = venue.Name,
						  BookingCount = stat.BookingCount
					  })
				.ToList();

			ViewBag.StartDate = startDate?.ToString("yyyy-MM-dd");
			ViewBag.EndDate = endDate?.ToString("yyyy-MM-dd");

			return View(venueDetails);
		}

		public IActionResult VendorPerformance(string? category, DateTime? startDate, DateTime? endDate)
		{
			var vendors = _context.Vendors
				.Include(v => v.VendorPackages)
				.ThenInclude(p => p.Bookings)
				.AsQueryable();

			if (!string.IsNullOrEmpty(category))
			{
				vendors = vendors.Where(v => v.Category == category);
			}

			var vendorPerformance = vendors
				.Select(v => new VendorPerformanceViewModel
				{
					VendorName = v.Name,
					Category = v.Category,
					BookingCount = v.VendorPackages
						.SelectMany(p => p.Bookings)
						.Where(b => (!startDate.HasValue || b.EventDate >= startDate)
								 && (!endDate.HasValue || b.EventDate <= endDate))
						.Count()
				})
				.OrderByDescending(v => v.BookingCount)
				.ToList();

			ViewBag.Categories = _context.Vendors.Select(v => v.Category).Distinct().ToList();
			ViewBag.SelectedCategory = category;

			return View(vendorPerformance);
		}

		public IActionResult AverageBudgetReport()
		{
			// Get the user session object from the session
			var userSession = HttpContext.Session.GetObject<UserSession>("UserSession");

			if (userSession == null)
			{
				return RedirectToAction("Login", "Account");  // Adjust this to your actual login route
			}

			int userId = userSession.UserId;

			var planner = _context.Planners.FirstOrDefault(p => p.UserID == userId);

			if (planner == null)
			{
				return RedirectToAction("Login", "Account");
			}

			int plannerId = planner.PlannerId;

			var coupleUserIds = _context.Bookings
				.Where(b => b.PlannerId == plannerId)
				.Select(b => b.UserID)
				.Distinct()
				.ToList();

			var coupleBudgets = _context.budgets
				.Where(b => coupleUserIds.Contains(b.UserId))
				.GroupBy(b => b.UserId)
				.Select(g => new CoupleBudgetViewModel
				{
					Name = _context.Users.Where(u => u.UserID == g.Key).Select(u => u.Fullname).FirstOrDefault(),
					TotalBudget = g.Sum(b => b.AllocatedAmount ?? 0) // Using null-coalescing operator
				})
				.ToList();

			decimal averageBudget = coupleBudgets.Any()
				? coupleBudgets.Average(cb => cb.TotalBudget)
				: 0;

			ViewBag.CoupleBudgets = coupleBudgets;
			ViewBag.AverageBudget = averageBudget;

			return View();
		}


		//public IActionResult AverageBudget()
		//{
		//	int plannerUserId = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)); // logged-in planner

		//	// Get this planner's ID
		//	var plannerId = _context.Planners
		//		.Where(p => p.UserID == plannerUserId)
		//		.Select(p => p.PlannerId)
		//		.FirstOrDefault();

		//	// Get UserIds of couples assigned to this planner
		//	var coupleIds = _context.Bookings
		//		.Where(b => b.PlannerId == plannerId)
		//		.Select(b => b.UserID)
		//		.Distinct()
		//		.ToList();

		//	// Get couple names and total budget per couple
		//	var coupleBudgets = _context.Users
		//		.Where(u => coupleIds.Contains(u.UserID))
		//		.Select(u => new CoupleBudgetViewModel
		//		{
		//			Fullname = u.Fullname,
		//			TotalBudget = _context.budgets
		//				.Where(b => b.UserId == u.UserID)
		//				.Sum(b => (decimal?)b.AllocatedAmount) ?? 0
		//		})
		//		.ToList();

		//	ViewBag.CoupleBudgets = coupleBudgets;
		//	ViewBag.AverageBudget = coupleBudgets.Any()
		//		? coupleBudgets.Average(cb => cb.TotalBudget)
		//		: 0;

		//	return View();
		//}


		//public IActionResult AverageBudget(int? coupleId)
		//{
		//	// 1. Get planner UserId from session
		//	var userSession = HttpContext.Session.GetObject<UserSession>("UserSession");
		//	if (userSession == null)
		//	{
		//		return RedirectToAction("Login", "Account");
		//	}

		//	int userId = userSession.UserId;

		//	// 2. Get PlannerId from Planner table using UserId
		//	var planner = _context.Planners.FirstOrDefault(p => p.UserID == userId);
		//	if (planner == null)
		//	{
		//		return RedirectToAction("Login", "Account");
		//	}

		//	int plannerId = planner.PlannerId;
		//	ViewBag.PlannerId = plannerId;

		//	// 3. Get all couple UserIds (UserId in Budget = CoupleId) for this planner
		//	var coupleIds = _context.Bookings
		//		.Where(b => b.PlannerId == plannerId)
		//		.Select(b => b.UserID)
		//		.Distinct()
		//		.ToList();

		//	// 4. Fetch couple names from Users table
		//	var coupleList = _context.Users
		//		.Where(u => coupleIds.Contains(u.UserID))
		//		.Select(u => new CoupleViewModel
		//		{
		//			UserID = u.UserID,
		//			Fullname = u.Fullname,
		//			PhoneNumber = u.PhoneNo
		//		}).ToList();

		//	// 5. Fetch the budget data for the selected couple or all couples
		//	if (coupleId.HasValue)
		//	{
		//		// Get budget details for the selected couple
		//		var coupleBudget = _context.budgets
		//			.Where(b => b.UserId == coupleId.Value)
		//			.ToList();

		//		// Calculate total allocated amount and average allocated budget
		//		var totalAllocated = coupleBudget.Sum(b => b.AllocatedAmount);
		//		var averageAllocatedBudget = coupleBudget.Any() ? totalAllocated / coupleBudget.Count : 0;

		//		// Calculate total actual amount and average actual budget
		//		var totalActual = coupleBudget.Sum(b => b.ActualAmount);
		//		var averageActualBudget = coupleBudget.Any() ? totalActual / coupleBudget.Count : 0;

		//		// Passing the calculated values to ViewBag for display
		//		ViewBag.AverageAllocatedBudget = averageAllocatedBudget;
		//		ViewBag.AverageActualBudget = averageActualBudget;
		//	}

		//	ViewBag.Couples = coupleList;
		//	return View();
		//}


		//	public IActionResult AverageBudget()
		//	{
		//		// 1. Get planner UserId from session
		//		var userSession = HttpContext.Session.GetObject<UserSession>("UserSession");
		//		if (userSession == null)
		//		{
		//			return RedirectToAction("Login", "Account");
		//		}

		//		int userId = userSession.UserId;

		//		// 2. Get PlannerId from Planner table using UserId
		//		var planner = _context.Planners.FirstOrDefault(p => p.UserID == userId);
		//		if (planner == null)
		//		{
		//			return RedirectToAction("Login", "Account");
		//		}

		//		int plannerId = planner.PlannerId;
		//		ViewBag.PlannerId = plannerId;

		//		// 3. Get all couple UserIds (UserId in Booking = CoupleId) for this planner
		//		var coupleIds = _context.Bookings
		//			.Where(b => b.PlannerId == plannerId)
		//			.Select(b => b.UserID)
		//			.Distinct()
		//			.ToList();

		//		// 4. Fetch couple names from Users table
		//		//var couples = _context.Users
		//		var coupleList = _context.Users
		//.Where(u => coupleIds.Contains(u.UserID))
		//.Select(u => new CoupleViewModel
		//{
		//	UserID = u.UserID,
		//	Fullname = u.Fullname,
		//	PhoneNumber = u.PhoneNo
		//}).ToList();

		//		ViewBag.Couples = coupleList;

		//		ViewBag.Couples = coupleList;
		//		return View();
		//	}

	}
}

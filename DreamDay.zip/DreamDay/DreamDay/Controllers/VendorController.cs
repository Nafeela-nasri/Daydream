﻿using DreamDay.Data;
using DreamDay.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.IO;

namespace DreamDay.Controllers
{
    public class VendorController : Controller
    {
        private readonly ApplicationDbContext _context;

        public VendorController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Vendor/AdminVendor
        public IActionResult AdminVendor()
        {
            return View(new Vendor());
        }

        // POST: Vendor/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Vendor vendor, IFormFile titleImage)
        {
            if (ModelState.IsValid)
            {
                if (titleImage != null && titleImage.Length > 0)
                {
                    using (var memoryStream = new MemoryStream())
                    {
                        titleImage.CopyTo(memoryStream);
                        vendor.TitleImage = memoryStream.ToArray();
                    }
                }

                _context.Vendors.Add(vendor);
                _context.SaveChanges();

                ViewBag.SuccessMessage = "Vendor submitted successfully!";
                return View("AdminVendor", new Vendor());
            }

            return View("AdminVendor", vendor);
        }

        // Viewing vendor data
        public IActionResult ViewVendor()
        {
            var vendors = _context.Vendors.ToList();
            return View(vendors);
        }

        // GET: VendorEdit
        public IActionResult VendorEdit(int id)
        {
            var vendor = _context.Vendors.Find(id);
            if (vendor == null)
            {
                return NotFound();
            }
            return View(vendor);
        }

        // POST: VendorEdit
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult VendorEdit(int id, Vendor updatedVendor, IFormFile? TitleImage)
        {
            var vendor = _context.Vendors.Find(id);
            if (vendor == null)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                vendor.Name = updatedVendor.Name;
                vendor.Category = updatedVendor.Category;
                vendor.PhoneNo = updatedVendor.PhoneNo;
                vendor.Address = updatedVendor.Address;
                vendor.City = updatedVendor.City;

                if (TitleImage != null && TitleImage.Length > 0)
                {
                    using (var ms = new MemoryStream())
                    {
                        TitleImage.CopyTo(ms);
                        vendor.TitleImage = ms.ToArray();
                    }
                }

                _context.SaveChanges();
                TempData["SuccessMessage"] = "Vendor updated successfully!";
                return RedirectToAction("ViewVendor");
            }

            return View(updatedVendor);
        }

        // GET: Vendor/Delete/5
        public IActionResult VendorDelete(int id)
        {
            var vendor = _context.Vendors.FirstOrDefault(v => v.VendorId == id);
            if (vendor == null)
            {
                return NotFound();
            }

            return View(vendor);
        }

        // POST: Vendor/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult VendorDeleteConfirmed(int id)
        {
            var vendor = _context.Vendors.FirstOrDefault(v => v.VendorId == id);
            if (vendor == null)
            {
                return NotFound();
            }

            _context.Vendors.Remove(vendor);
            _context.SaveChanges();
            TempData["SuccessMessage"] = "Vendor deleted successfully!";
            return RedirectToAction("ViewVendor");
        }
    }
}

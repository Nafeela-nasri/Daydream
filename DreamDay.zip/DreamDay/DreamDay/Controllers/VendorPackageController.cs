﻿using Microsoft.AspNetCore.Mvc;
using DreamDay.Models;
using Microsoft.AspNetCore.Http;
using DreamDay.Data;
using DreamDay.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.IO;


namespace DreamDay.Controllers
{
    public class VendorPackageController : Controller
    {
        private readonly ApplicationDbContext _context;

        public VendorPackageController(ApplicationDbContext context)
        {
            _context = context;
        }

        // Show the form
        public IActionResult PackageCreate()
        {
            ViewBag.Vendors = _context.Vendors.ToList();
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult PackageCreate(VendorPackage vendorPackage, IFormFile ImageFile)
        {
            if (ImageFile != null && ImageFile.Length > 0)
            {
                using (var ms = new MemoryStream())
                {
                    ImageFile.CopyTo(ms);
                    vendorPackage.Image = ms.ToArray();
                }
            }

            _context.VendorPackages.Add(vendorPackage);
            _context.SaveChanges();

            TempData["Success"] = "Vendor Package added successfully!";
            return RedirectToAction("PackageCreate");
        }

        public IActionResult ViewPackages()
        {
            var packages = _context.VendorPackages.Include(v => v.Vendor).ToList();
            return View(packages);
        }
        // GET
        [HttpGet]
        public async Task<IActionResult> EditPackage(int id)
        {
            var package = await _context.VendorPackages.FindAsync(id);
            if (package == null)
            {
                return NotFound();
            }
            return View(package);
        }

        // POST
        [HttpPost]
        public async Task<IActionResult> EditPackage(int id, VendorPackage updatedPackage, IFormFile ImageFile)
        {
            var existingPackage = await _context.VendorPackages.FindAsync(id);
            if (existingPackage == null)
            {
                return NotFound();
            }

            existingPackage.PackageName = updatedPackage.PackageName;
            existingPackage.Description = updatedPackage.Description;
            existingPackage.Price = updatedPackage.Price;

            if (ImageFile != null && ImageFile.Length > 0)
            {
                using (var ms = new MemoryStream())
                {
                    await ImageFile.CopyToAsync(ms);
                    existingPackage.Image = ms.ToArray();
                }
            }

            _context.Update(existingPackage);
            await _context.SaveChangesAsync();

            TempData["Success"] = "Package updated successfully!";
            return RedirectToAction("ViewPackages");
        }
        // GET: VendorPackage/Delete/5
        public IActionResult DeletePackage(int id)
        {
            var package = _context.VendorPackages.FirstOrDefault(p => p.PackageId == id);
            if (package == null)
            {
                return NotFound();
            }

            return View(package);
        }

        // POST: VendorPackage/Delete/5
        // POST: VendorPackage/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult VendorPackageDeleteConfirmed(int id)
        {
            var package = _context.VendorPackages.FirstOrDefault(p => p.PackageId == id);
            if (package == null)
            {
                return NotFound();
            }

            _context.VendorPackages.Remove(package);
            _context.SaveChanges();
            TempData["Success"] = "Vendor Package deleted successfully!"; // Set success message in TempData
            return RedirectToAction("PackageCreate"); // Redirect to PackageCreate action
        }
    }

}

﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using DreamDay.Models;
using DreamDay.Data;
using DreamDay.Helpers;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Numerics;

namespace DreamDay.Controllers // ADD THIS
{
    public class PlannerController : Controller
    {
        private readonly ApplicationDbContext _context;

        public PlannerController(ApplicationDbContext context)
        {
            _context = context;
        }
        public IActionResult Dashboard()
        {
            try
            {
                // Step 1: Get UserSession object first
                var userSession = HttpContext.Session.GetObject<UserSession>("UserSession");

                // Step 2: If UserSession object is null, try individual session values
                if (userSession == null)
                {
                    var userIdFromSession = HttpContext.Session.GetInt32("UserID");
                    var userRoleFromSession = HttpContext.Session.GetString("UserRole");

                    // If individual session values exist, recreate UserSession
                    if (userIdFromSession.HasValue && !string.IsNullOrEmpty(userRoleFromSession))
                    {
                        // Get user details from database to reconstruct session
                        var user = _context.Users.FirstOrDefault(u => u.UserID == userIdFromSession.Value);
                        if (user != null)
                        {
                            userSession = new UserSession
                            {
                                UserId = user.UserID,
                                UserRole = user.UserRole,
                                UserName = user.Fullname
                            };

                            // Re-store the session object for future use
                            HttpContext.Session.SetObject("UserSession", userSession);
                        }
                    }
                }

                // Step 3: Final check - if still no valid session, redirect to login
                if (userSession == null)
                {
                    TempData["LoginMessage"] = "Session expired. Please log in again.";
                    return RedirectToAction("Login", "Account");
                }

                int userId = userSession.UserId;

                // Step 4: Check if user has planner role
                if (userSession.UserRole != "Wedding Planner")
                {
                    TempData["ErrorMessage"] = "Access denied. This area is for wedding planners only.";
                    return RedirectToAction("Login", "Account");
                }

                // Step 5: Check if planner profile exists
                var planner = _context.Planners.FirstOrDefault(p => p.UserID == userId);
                if (planner == null)
                {
                    // If no planner profile exists, redirect to create profile
                    TempData["InfoMessage"] = "Please complete your planner profile first.";
                    return RedirectToAction("Create", "Planner");
                }

                int plannerId = planner.PlannerId;
                ViewBag.PlannerId = plannerId;

                // Step 6: Get couples (clients who have bookings with this planner)
                var coupleIds = _context.Bookings
                    .Where(b => b.PlannerId == plannerId)
                    .Select(b => b.UserID)
                    .Distinct()
                    .ToList();

                var coupleList = _context.Users
                    .Where(u => coupleIds.Contains(u.UserID))
                    .Select(u => new CoupleViewModel
                    {
                        UserID = u.UserID,
                        Fullname = u.Fullname,
                        PhoneNumber = u.PhoneNo
                    })
                    .ToList();

                ViewBag.Couples = coupleList;

                // Debug information (optional - remove in production)
                ViewBag.DebugUserId = userId;
                ViewBag.DebugPlannerId = plannerId;
                ViewBag.DebugSessionId = HttpContext.Session.Id;

                return View();
            }
            catch (Exception ex)
            {
                // Log the error for debugging
                System.Diagnostics.Debug.WriteLine($"Dashboard Error: {ex.Message}");
                System.Diagnostics.Debug.WriteLine($"Stack Trace: {ex.StackTrace}");

                TempData["ErrorMessage"] = "An error occurred while loading the dashboard. Please try logging in again.";
                return RedirectToAction("Login", "Account");
            }
        }


        //GET: Planner/Create
        //GET
        public IActionResult Create()
		{
			var userSession = HttpContext.Session.GetObject<UserSession>("UserSession");
			if (userSession == null)
			{
				TempData["ErrorMessage"] = "Session expired. Please log in again.";
				return RedirectToAction("Login", "Account");
			}
			int userId = userSession.UserId;
			ViewBag.UserId = userId;
			return View();

		}



		// Zeena code may 1st*@

		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> Create(Planner planner, IFormFile Image)
		{
			if (!ModelState.IsValid)
			{
				return View(planner);
			}

			var exists = await _context.Planners
				.AnyAsync(p => p.BusinessRegNo == planner.BusinessRegNo);

			if (exists)
			{
				ModelState.AddModelError("BusinessRegNo", "This registration number is already used.");
				return View(planner);
			}

			try
			{
				var userSession = HttpContext.Session.GetObject<UserSession>("UserSession");
				if (userSession == null)
				{
					TempData["ErrorMessage"] = "Session expired. Please log in again.";
					return RedirectToAction("Login", "Account");
				}
				int userId = userSession.UserId;
				planner.UserID = userId;


				// Handle image upload
				if (Image != null && Image.Length > 0)
				{
					using (var ms = new MemoryStream())
					{
						await Image.CopyToAsync(ms);
						planner.Image = ms.ToArray();
					}
				}

				_context.Planners.Add(planner);
				await _context.SaveChangesAsync();

				TempData["SuccessMessage"] = "Planner added successfully!";
				return RedirectToAction("Dashboard");
			}
			catch
			{
				TempData["ErrorMessage"] = "Failed to add planner.";
				return RedirectToAction("Create");
			}
		}


		//ZOona code
		//     // POST: Planner/Create
		//     [HttpPost]
		//     [ValidateAntiForgeryToken]
		//     public async Task<IActionResult> Create(Planner planner, IFormFile Image)
		//     {


		//if (!ModelState.IsValid)
		//         {
		//             return View(planner);
		//         }

		//         var exists = await _context.Planners
		//             .AnyAsync(p => p.BusinessRegNo == planner.BusinessRegNo);

		//         if (exists)
		//         {
		//             ModelState.AddModelError("BusinessRegNo", "This registration number is already used.");
		//             return View(planner);
		//         }

		//         try
		//         {
		//             planner.UserID = 1; // Replace with real user ID

		//             if (Image != null && Image.Length > 0)
		//             {
		//                 using (var ms = new MemoryStream())
		//                 {
		//                     await Image.CopyToAsync(ms);
		//                     planner.Image = ms.ToArray();
		//                 }
		//             }

		//             _context.Planners.Add(planner);
		//             await _context.SaveChangesAsync();

		//             TempData["SuccessMessage"] = "Planner added successfully!";
		//             return RedirectToAction("Dashboard");
		//         }
		//         catch
		//         {
		//             TempData["ErrorMessage"] = "Failed to add planner.";
		//             return RedirectToAction("Create");
		//         }
		//     }


		public async Task<IActionResult> SelectPlanner()
        {
            var userSession = HttpContext.Session.GetObject<UserSession>("UserSession");

            if (userSession == null)
            {
                return RedirectToAction("Login", "Account");
            }

            ViewBag.UserId = userSession.UserId;

            var planners = await _context.Planners
                .Include(p => p.User)
                .Include(p => p.Reviews) 
                .ToListAsync();

            var venues = await _context.Venues.ToListAsync();
            var vendors = await _context.Vendors.ToListAsync();

            ViewBag.Venues = venues;
            ViewBag.Vendors = vendors;

            return View(planners);
        }




        [HttpGet]
        public async Task<IActionResult> GetVenueDetails(int venueId)
        {
            var venue = await _context.Venues
                .Where(v => v.VenueId == venueId)
                .Include(v => v.Reviews) // Make sure to include reviews
                .FirstOrDefaultAsync();

            if (venue == null)
            {
                return NotFound();
            }

            var venueDetails = new
            {
                name = venue.Name,
                phoneNo = venue.PhoneNo,
                address = venue.Address,
                city = venue.City,
                capacity = venue.Capacity,
                price = venue.Price,
                image = venue.Image != null ? Convert.ToBase64String(venue.Image) : null,
                titleImage = venue.TitleImage != null ? Convert.ToBase64String(venue.TitleImage) : null,
                reviews = venue.Reviews.Select(r => new
                {
                    r.Id,
                    r.Comment
                }).ToList()
            };

            return Json(venueDetails);
        }


        // Action to get vendor details along with their packages
        // Action to get vendor details along with their packages and reviews
        [HttpGet]
        public IActionResult GetVendorDetails(int vendorId)
        {
            var vendor = _context.Vendors
                .Where(v => v.VendorId == vendorId)
                .Select(v => new
                {
                    v.Name,
                    v.Category,
                    v.PhoneNo,
                    v.Address,
                    TitleImage = Convert.ToBase64String(v.TitleImage),  // Assuming TitleImage is stored as a byte array
                    VendorPackages = v.VendorPackages.Select(p => new
                    {
                        p.PackageId,
                        p.PackageName,
                        p.Price,
                        Image = Convert.ToBase64String(p.Image),  // Assuming Image is stored as a byte array
                    }).ToList(),
                    Reviews = v.Reviews.Select(r => new
                    {
                        r.Id,  // Use Id (not ReviewId)
                        r.Comment // Only include Comment as per your current model
                    }).ToList()
                })
                .FirstOrDefault();

            if (vendor == null)
            {
                return NotFound();
            }

            return Json(vendor);
        }


        // Action to get details of a single VendorPackage
       [HttpGet]
        public IActionResult GetVendorPackageDetails(int packageId)
        {
            var package = _context.VendorPackages
                .Include(p => p.Vendor) // Ensure vendor is included
                .Where(p => p.PackageId == packageId)
                .Select(p => new
                {
                    p.PackageName,
                    p.Description,
                    p.Price,
                    Image = Convert.ToBase64String(p.Image),
                    Category = p.Vendor.Category // Include the vendor category
                })
                .FirstOrDefault();

            if (package == null)
            {
                return NotFound();
            }

            return Json(package);
        }

        // Action to display the list of vendors (used in the vendor list page)
        public IActionResult VendorList()
        {
            var vendors = _context.Vendors
                .Select(v => new
                {
                    v.VendorId,
                    v.Name
                })
                .ToList();

            return View(vendors);
        }





		//CODE FOR TRACK VENDOR AVAILABILITY
		//public IActionResult TrackVendorAvailability()
		//{
		//	return View();
		//}

		// View all vendors
		// GET: Admin/VendorIndex
		//public IActionResult TrackVendorAvailability(string? category)
		//{
		//	var vendors = _context.Vendors.AsQueryable();

		//	if (!string.IsNullOrEmpty(category))
		//		vendors = vendors.Where(v => v.Category == category);

		//	ViewBag.Categories = _context.Vendors.Select(v => v.Category).Distinct().ToList();
		//	ViewBag.SelectedCategory = category;

		//	return View(vendors.ToList());
		//}


		public IActionResult TrackVendorAvailability(string? category, DateTime? date)
		{
			// Get all categories for dropdown
			ViewBag.Categories = _context.Vendors.Select(v => v.Category).Distinct().ToList();
			ViewBag.SelectedCategory = category;
			ViewBag.SelectedDate = date?.ToString("yyyy-MM-dd");

			if (string.IsNullOrEmpty(category) || !date.HasValue)
			{
				// If no filter applied yet, show empty or all vendors
				return View(new List<Vendor>());
			}

			// Step 1: Get PackageIds already booked on the given date
			var bookedPackageIds = _context.Bookings
				.Where(b => b.EventDate.Date == date.Value.Date)
				.Select(b => b.PackageId)
				.ToList();

			// Step 2: Get VendorIds from those PackageIds
			var bookedVendorIds = _context.VendorPackages
				.Where(vp => bookedPackageIds.Contains(vp.PackageId))
				.Select(vp => vp.VendorId)
				.ToList();

			// Step 3: Get vendors NOT in bookedVendorIds and match the selected category
			var availableVendors = _context.Vendors
				.Where(v => v.Category == category && !bookedVendorIds.Contains(v.VendorId))
				.ToList();

			return View(availableVendors);
		}

	}
}

﻿using DreamDay.Data;
using DreamDay.Models;
using Microsoft.AspNetCore.Mvc;

namespace DreamDay.Controllers
{
    public class PaymentController : Controller
    {
        private readonly ApplicationDbContext _context;

        public PaymentController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public IActionResult Make(int userId, int? plannerId)
        {
            ViewBag.UserID = userId;
            ViewBag.PlannerID = plannerId;
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Make(Payment payment)
        {
            if (ModelState.IsValid)
            {
                payment.Date = DateTime.Now;

                _context.Payments.Add(payment);
                await _context.SaveChangesAsync();

                // Save dynamic receipt info
                TempData["Success"] = "Your payment was processed successfully.";
                TempData["Amount"] = payment.Amount.ToString("C");
                TempData["Date"] = payment.Date.ToString("MMMM dd, yyyy - hh:mm tt");
                TempData["Reference"] = Guid.NewGuid().ToString().Substring(0, 8).ToUpper();

                return RedirectToAction("Success");
            }

            // Re-populate viewbags on error
            ViewBag.UserID = payment.UserID;
            ViewBag.PlannerID = payment.PlannerID;

            return View(payment);
        }

        public IActionResult Success()
        {
            return View();
        }
    }
}

﻿using DreamDay.Data;
using DreamDay.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace DreamDay.Controllers
{
    public class ReviewController : Controller
    {
        private readonly ApplicationDbContext _context;

        public ReviewController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public IActionResult Create(int? vendorId, int? venueId, int? plannerId)
        {
            var review = new Review();

            // Set VendorId, VenueId, and PlannerId based on passed parameters
            if (vendorId.HasValue)
                review.VendorId = vendorId;

            if (venueId.HasValue)
                review.VenueId = venueId;

            if (plannerId.HasValue)
                review.PlannerId = plannerId;

            return View(review);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Review review)
        {
            // Ensure that VendorId, VenueId, or PlannerId are provided
            if (review.VendorId == null && review.VenueId == null && review.PlannerId == null)
            {
                ModelState.AddModelError("", "VendorId, VenueId, or PlannerId is required.");
                return View(review);
            }

            if (ModelState.IsValid)
            {
                _context.Reviews.Add(review);
                await _context.SaveChangesAsync();
                TempData["SuccessMessage"] = "Successfully feedback added!";
                return RedirectToAction("SelectPlanner", "Planner");
            }

            return View(review);
        }
    }
}

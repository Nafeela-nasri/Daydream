﻿using Microsoft.AspNetCore.Mvc;
using DreamDay.Models;
using System.IO;
using DreamDay.Data;

namespace DreamDay.Controllers
{
    public class VenueController : Controller
    {
        private readonly ApplicationDbContext _context;

        public VenueController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: AdminVenue
        public IActionResult AdminVenue()
        {
            return View(new Venue());
        }

        // POST: AdminVenue/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Venue venue, IFormFile titleImage, IFormFile image)
        {
            if (!ModelState.IsValid)
            {
                return View("AdminVenue", venue);
            }

            venue.TitleImage = ProcessImage(titleImage);
            venue.Image = ProcessImage(image);

            _context.Venues.Add(venue);
            _context.SaveChanges();

            ViewBag.SuccessMessage = "Venue submitted successfully!";
            ModelState.Clear(); // Clear the form

            return View("AdminVenue", new Venue());
        }

        // GET: Venue/View
        public IActionResult VenueView()
        {
            var venues = _context.Venues.ToList();
            return View(venues);
        }

        // GET: Venue/Edit/5
        public IActionResult VenueEdit(int id)
        {
            var venue = _context.Venues.FirstOrDefault(v => v.VenueId == id);
            if (venue == null)
            {
                return NotFound();
            }

            return View(venue); // <-- This looks for a view named `VenueEdit.cshtml`
        }


        // POST: Venue/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult VenueEdit(int id, Venue venue, IFormFile titleImage, IFormFile image)
        {
            if (id != venue.VenueId)
            {
                return NotFound();
            }

            if (!ModelState.IsValid)
            {
                return View("VenueEdit", venue);
            }

            var existingVenue = _context.Venues.FirstOrDefault(v => v.VenueId == id);
            if (existingVenue == null)
            {
                return NotFound();
            }

            // Update fields
            existingVenue.Name = venue.Name;
            existingVenue.Capacity = venue.Capacity;
            existingVenue.Destination = venue.Destination;
            existingVenue.Price = venue.Price;
            existingVenue.PhoneNo = venue.PhoneNo;
            existingVenue.Address = venue.Address;
            existingVenue.City = venue.City;

            // Update images if uploaded
            var updatedTitleImage = ProcessImage(titleImage);
            var updatedImage = ProcessImage(image);

            if (updatedTitleImage != null)
            {
                existingVenue.TitleImage = updatedTitleImage;
            }

            if (updatedImage != null)
            {
                existingVenue.Image = updatedImage;
            }

            _context.SaveChanges();

            TempData["SuccessMessage"] = "Venue updated successfully!";
            return RedirectToAction("VenueView");
        }

        // GET: Venue/Delete/5
        public IActionResult VenueDelete(int id)
        {
            var venue = _context.Venues.FirstOrDefault(v => v.VenueId == id);
            if (venue == null)
            {
                return NotFound();
            }

            return View(venue);
        }

        // POST: Venue/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult VenueDeleteConfirmed(int id)
        {
            var venue = _context.Venues.FirstOrDefault(v => v.VenueId == id);
            if (venue == null)
            {
                return NotFound();
            }

            _context.Venues.Remove(venue);
            _context.SaveChanges();
            TempData["SuccessMessage"] = "Venue deleted successfully!";
            return RedirectToAction("VenueView");
        }

        // Utility method for processing uploaded images
        private byte[]? ProcessImage(IFormFile imageFile)
        {
            if (imageFile == null || imageFile.Length == 0)
            {
                return null;
            }

            using var memoryStream = new MemoryStream();
            imageFile.CopyTo(memoryStream);
            return memoryStream.ToArray();
        }
    }
}

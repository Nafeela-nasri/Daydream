﻿using DreamDay.Data;
using DreamDay.Helpers;
using DreamDay.Models;
using Microsoft.AspNetCore.Mvc;
using System.Linq;
using System.Security.Cryptography;
using System.Text;

namespace DreamDay.Controllers
{
    public class AccountController : Controller
    {
        private readonly ApplicationDbContext _db;

        public AccountController(ApplicationDbContext db)
        {
            _db = db;
        }

        // Display the registration form
        public IActionResult Register()
        {
            return View();
        }

        // Handle registration form submission
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Register(User user)
        {
            // Check if the email already exists in the database
            if (_db.Users.Any(u => u.Email == user.Email))
            {
                ModelState.AddModelError("Email", "Email is already registered.");
                return View(user); // Return with error if email exists
            }

            if (ModelState.IsValid)
            {
                // Hash the password
                user.Password = HashPassword(user.Password);
                _db.Users.Add(user);
                _db.SaveChanges();
                return RedirectToAction("Login");
            }

            return View(user);
        }

        // Hashing function
        private string HashPassword(string password)
        {
            using (var sha256 = SHA256.Create())
            {
                var hashBytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
                return Convert.ToBase64String(hashBytes);
            }
        }

        // Display the login form
        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        // Handle login form submission
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Login(string email, string password)
        {
            var user = _db.Users.FirstOrDefault(u => u.Email == email);

            if (user != null && VerifyPassword(password, user.Password))
            {
                var userSession = new UserSession
                {
                    UserId = user.UserID,
                    UserName = user.Fullname,
                    UserRole = user.UserRole
                };

                HttpContext.Session.SetObject("UserSession", userSession);

                // Also set individual session values as backup
                HttpContext.Session.SetInt32("UserID", user.UserID);
                HttpContext.Session.SetString("UserRole", user.UserRole);

                TempData["LoginDebug"] = $"User logged in with ID: {userSession.UserId}";

                // Redirect based on user role
                if (user.UserRole == "Admin")
                {
                    return RedirectToAction("Dashboard", "Admin");
                }
                else if (user.UserRole == "Wedding Planner")
                {
                    // Check if planner profile already exists
                    var existingPlanner = _db.Planners.FirstOrDefault(p => p.UserID == user.UserID);
                    if (existingPlanner != null)
                    {
                        // Profile exists, go to dashboard
                        return RedirectToAction("Dashboard", "Planner");
                    }
                    else
                    {
                        // No profile exists, go to create profile
                        return RedirectToAction("Create", "Planner");
                    }
                }
                else
                {
                    return RedirectToAction("Index", "CoupleDashbaord");
                }
            }

            ModelState.AddModelError("", "Invalid login attempt.");
            return View();
        }

        // Verify password with stored hash
        private bool VerifyPassword(string inputPassword, string storedPassword)
        {
            using (var sha256 = SHA256.Create())
            {
                var hashBytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(inputPassword));
                return Convert.ToBase64String(hashBytes) == storedPassword;
            }
        }

        public IActionResult Logout()
        {
            // Clear the session
            HttpContext.Session.Clear();

            // Redirect to the login page
            return RedirectToAction("Login");
        }
    }
}

﻿using Microsoft.AspNetCore.Mvc;
using DreamDay.Models;
using DreamDay.Data;
using Microsoft.EntityFrameworkCore;
using DreamDay.Helpers;

namespace DreamDay.Controllers
{
    public class GuestController : Controller
    {
        private readonly ApplicationDbContext _context;

        public GuestController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Guest/GuestList - Main guest list view for couples
        public IActionResult GuestList()
        {
            // Check if user is logged in and is a couple
            var userId = GetCurrentUserId();
            if (userId == null)
            {
                TempData["ErrorMessage"] = "Please log in to access the guest list.";
                return RedirectToAction("Login", "Account");
            }

            var user = _context.Users.FirstOrDefault(u => u.UserID == userId && u.UserRole == "Couple");
            if (user == null)
            {
                TempData["ErrorMessage"] = "Only couples can access the guest list.";
                return Forbid(); // Only couples can access guest list
            }

            var guests = _context.Guests
                .Where(g => g.UserId == userId.Value)
                .OrderBy(g => g.Name)
                .ToList();

            ViewBag.TotalGuests = guests.Sum(g => g.AccompanyingGuests);
            ViewBag.AcceptedGuests = guests.Where(g => g.RSVPStatus == "Accepted").Sum(g => g.AccompanyingGuests);
            ViewBag.PendingGuests = guests.Where(g => g.RSVPStatus == "Pending").Sum(g => g.AccompanyingGuests);
            ViewBag.DeclinedGuests = guests.Where(g => g.RSVPStatus == "Declined").Sum(g => g.AccompanyingGuests);

            return View(guests);
        }

        // GET: Guest/AddGuest - Form to add new guest
        public IActionResult AddGuest()
        {
            var userId = GetCurrentUserId();
            if (userId == null)
            {
                TempData["ErrorMessage"] = "Please log in to add guests.";
                return RedirectToAction("Login", "Account");
            }

            if (!IsCouple(userId.Value))
            {
                TempData["ErrorMessage"] = "Only couples can add guests.";
                return Forbid();
            }

            // Add debug information
            ViewBag.DebugUserId = userId;
            ViewBag.DebugUserRole = HttpContext.Session.GetString("UserRole");
            ViewBag.DebugSessionId = HttpContext.Session.Id;

            var guest = new Guest 
            { 
                UserId = userId.Value,
                InvitationStatus = "Not Sent",
                RSVPStatus = "Pending",
                AccompanyingGuests = 1
            };

            return View(guest);
        }

        // POST: Guest/AddGuest - Create new guest
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult AddGuest(Guest guest)
        {
            var userId = GetCurrentUserId();
            if (userId == null)
            {
                TempData["ErrorMessage"] = "Session expired. Please log in again.";
                return RedirectToAction("Login", "Account");
            }

            if (!IsCouple(userId.Value))
            {
                TempData["ErrorMessage"] = "Only couples can add guests.";
                return Forbid();
            }

            // Ensure UserId is set correctly
            guest.UserId = userId.Value;

            // Add debug information
            ViewBag.DebugUserId = userId;
            ViewBag.DebugUserRole = HttpContext.Session.GetString("UserRole");
            ViewBag.DebugSessionId = HttpContext.Session.Id;

            // Manual validation for required fields
            var validationErrors = new List<object>();

            if (string.IsNullOrWhiteSpace(guest.Name))
            {
                ModelState.AddModelError("Name", "Guest name is required.");
                validationErrors.Add(new { Field = "Name", Errors = new[] { "Guest name is required." } });
            }

            if (string.IsNullOrWhiteSpace(guest.GuestType))
            {
                ModelState.AddModelError("GuestType", "Guest type is required.");
                validationErrors.Add(new { Field = "GuestType", Errors = new[] { "Guest type is required." } });
            }

            // Set default values
            if (string.IsNullOrEmpty(guest.InvitationStatus))
                guest.InvitationStatus = "Not Sent";
            
            if (string.IsNullOrEmpty(guest.RSVPStatus))
                guest.RSVPStatus = "Pending";
            
            if (guest.AccompanyingGuests <= 0)
                guest.AccompanyingGuests = 1;

            // Check ModelState and provide detailed validation errors
            if (!ModelState.IsValid)
            {
                // Add all ModelState errors to validation errors
                var allValidationErrors = ModelState
                    .Where(x => x.Value.Errors.Count > 0)
                    .Select(x => new { 
                        Field = x.Key, 
                        Errors = x.Value.Errors.Select(e => e.ErrorMessage).ToArray() 
                    }).ToList();
                
                ViewBag.ValidationErrors = allValidationErrors;
                ViewBag.ErrorMessage = "Please correct the validation errors below.";
                
                return View(guest);
            }

            try
            {
                // Double-check the guest object before saving
                if (guest.UserId <= 0)
                {
                    ViewBag.ErrorMessage = "Invalid user session. Please try logging in again.";
                    return View(guest);
                }

                // Add the guest to context
                _context.Guests.Add(guest);
                
                // Save changes and get the number of affected records
                var result = _context.SaveChanges();

                if (result > 0)
                {
                    TempData["SuccessMessage"] = $"Guest '{guest.Name}' has been added successfully!";
                    return RedirectToAction("GuestList");
                }
                else
                {
                    ViewBag.ErrorMessage = "Failed to save guest to database. No records were affected.";
                    return View(guest);
                }
            }
            catch (DbUpdateException dbEx)
            {
                // Database-specific errors
                var errorMessage = "Database error occurred while adding guest.";
                if (dbEx.InnerException != null)
                {
                    errorMessage += $" Details: {dbEx.InnerException.Message}";
                }
                ViewBag.ErrorMessage = errorMessage;
                return View(guest);
            }
            catch (Exception ex)
            {
                // General exceptions
                ViewBag.ErrorMessage = $"An unexpected error occurred: {ex.Message}";
                return View(guest);
            }
        }

        // GET: Guest/EditGuest/5 - Edit guest form
        public IActionResult EditGuest(int id)
        {
            var userId = GetCurrentUserId();
            if (userId == null || !IsCouple(userId.Value))
            {
                return Forbid();
            }

            var guest = _context.Guests.FirstOrDefault(g => g.GuestId == id && g.UserId == userId.Value);
            if (guest == null)
            {
                return NotFound();
            }

            return View(guest);
        }

        // POST: Guest/EditGuest/5 - Update guest
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult EditGuest(int id, Guest guest)
        {
            var userId = GetCurrentUserId();
            if (userId == null || !IsCouple(userId.Value))
            {
                return Forbid();
            }

            if (id != guest.GuestId)
            {
                return NotFound();
            }

            var existingGuest = _context.Guests.FirstOrDefault(g => g.GuestId == id && g.UserId == userId.Value);
            if (existingGuest == null)
            {
                return NotFound();
            }

            if (!ModelState.IsValid)
            {
                return View(guest);
            }

            try
            {
                // Update fields
                existingGuest.Name = guest.Name;
                existingGuest.Email = guest.Email;
                existingGuest.PhoneNo = guest.PhoneNo;
                existingGuest.GuestType = guest.GuestType;
                existingGuest.InvitationStatus = guest.InvitationStatus;
                existingGuest.RSVPStatus = guest.RSVPStatus;
                existingGuest.MealPreference = guest.MealPreference;
                existingGuest.SpecialRequirements = guest.SpecialRequirements;
                existingGuest.TableAssignment = guest.TableAssignment;
                existingGuest.AccompanyingGuests = guest.AccompanyingGuests;
                existingGuest.Notes = guest.Notes;

                // Update RSVP date if status changed to Accepted or Declined
                if (guest.RSVPStatus != "Pending" && existingGuest.RSVPDate == null)
                {
                    existingGuest.RSVPDate = DateTime.Now;
                }

                _context.SaveChanges();

                TempData["SuccessMessage"] = "Guest updated successfully!";
                return RedirectToAction("GuestList");
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = $"Error updating guest: {ex.Message}";
                return View(guest);
            }
        }

        // GET: Guest/DeleteGuest/5 - Delete confirmation
        public IActionResult DeleteGuest(int id)
        {
            var userId = GetCurrentUserId();
            if (userId == null || !IsCouple(userId.Value))
            {
                return Forbid();
            }

            var guest = _context.Guests.FirstOrDefault(g => g.GuestId == id && g.UserId == userId.Value);
            if (guest == null)
            {
                return NotFound();
            }

            return View(guest);
        }

        // POST: Guest/DeleteGuest/5 - Confirm delete
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteGuestConfirmed(int id)
        {
            var userId = GetCurrentUserId();
            if (userId == null || !IsCouple(userId.Value))
            {
                return Forbid();
            }

            try
            {
                var guest = _context.Guests.FirstOrDefault(g => g.GuestId == id && g.UserId == userId.Value);
                if (guest == null)
                {
                    return NotFound();
                }

                _context.Guests.Remove(guest);
                _context.SaveChanges();

                TempData["SuccessMessage"] = "Guest deleted successfully!";
                return RedirectToAction("GuestList");
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = $"Error deleting guest: {ex.Message}";
                return RedirectToAction("GuestList");
            }
        }

        // GET: Guest/RSVPManagement - RSVP tracking view
        public IActionResult RSVPManagement()
        {
            var userId = GetCurrentUserId();
            if (userId == null || !IsCouple(userId.Value))
            {
                return Forbid();
            }

            var guests = _context.Guests
                .Where(g => g.UserId == userId.Value)
                .OrderBy(g => g.RSVPStatus)
                .ThenBy(g => g.Name)
                .ToList();

            return View(guests);
        }

        // GET: Guest/SeatingArrangement - Seating arrangement view
        public IActionResult SeatingArrangement()
        {
            var userId = GetCurrentUserId();
            if (userId == null || !IsCouple(userId.Value))
            {
                return Forbid();
            }

            var guests = _context.Guests
                .Where(g => g.UserId == userId.Value && g.RSVPStatus == "Accepted")
                .OrderBy(g => g.TableAssignment)
                .ThenBy(g => g.Name)
                .ToList();

            // Group guests by table
            var tableGroups = guests
                .GroupBy(g => g.TableAssignment ?? "Unassigned")
                .OrderBy(g => g.Key)
                .ToList();

            return View(tableGroups);
        }

        // POST: Guest/UpdateRSVP - Quick RSVP status update
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult UpdateRSVP(int guestId, string rsvpStatus)
        {
            var userId = GetCurrentUserId();
            if (userId == null || !IsCouple(userId.Value))
            {
                return Json(new { success = false, message = "Unauthorized" });
            }

            try
            {
                var guest = _context.Guests.FirstOrDefault(g => g.GuestId == guestId && g.UserId == userId.Value);
                if (guest == null)
                {
                    return Json(new { success = false, message = "Guest not found" });
                }

                guest.RSVPStatus = rsvpStatus;
                if (rsvpStatus != "Pending")
                {
                    guest.RSVPDate = DateTime.Now;
                }

                _context.SaveChanges();

                return Json(new { success = true, message = "RSVP status updated successfully" });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = $"Error updating RSVP: {ex.Message}" });
            }
        }

        // Helper method to get current user ID from session
        private int? GetCurrentUserId()
        {
            try
            {
                // Try to get from the individual session value first (backup method)
                var userIdFromSession = HttpContext.Session.GetInt32("UserID");
                if (userIdFromSession.HasValue)
                {
                    return userIdFromSession.Value;
                }

                // Try to get from UserSession object
                var userSession = HttpContext.Session.GetObject<UserSession>("UserSession");
                if (userSession != null)
                {
                    return userSession.UserId;
                }

                return null;
            }
            catch (Exception)
            {
                return null;
            }
        }

        // Helper method to check if user is a couple
        private bool IsCouple(int userId)
        {
            try
            {
                // First check from session for better performance
                var userRole = HttpContext.Session.GetString("UserRole");
                if (!string.IsNullOrEmpty(userRole) && userRole == "Couple")
                {
                    return true;
                }

                // Fallback to database check
                var user = _context.Users.FirstOrDefault(u => u.UserID == userId);
                return user?.UserRole == "Couple";
            }
            catch (Exception)
            {
                return false;
            }
        }
    }
}